import * as T from 'three';
import {CLOUD_LIGHT_GLSL} from './cloud-light';

/** Crossed, segmented stems and individual grains remain volumetric from the side. */
export function buildFields(scene:T.Scene,ground:(x:number,z:number)=>number){
 let seed=7219;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const vertices:number[]=[],normals:number[]=[],colors:number[]=[];
 function triangle(a:number[],b:number[],c:number[],color:T.Color){
  const n=new T.Vector3().crossVectors(new T.Vector3().fromArray(b).sub(new T.Vector3().fromArray(a)),new T.Vector3().fromArray(c).sub(new T.Vector3().fromArray(a))).normalize();
  vertices.push(...a,...b,...c);for(let i=0;i<3;i++){normals.push(n.x,n.y,n.z);colors.push(color.r,color.g,color.b);}
 }
 function leaf(a:number[],b:number[],c:number[],d:number[],color:T.Color){triangle(a,b,c,color);triangle(a,c,d,color);}
 const stem=new T.Color('#728575'),ear=new T.Color('#d0b871'),tip=new T.Color('#e3cf8c');
 for(let axis=0;axis<2;axis++)for(let segment=0;segment<3;segment++){
  const y=segment*.27,h=y+.27,w=.014;
  leaf(axis?[0,y,-w]:[-w,y,0],axis?[0,y,w]:[w,y,0],axis?[0,h,w]:[w,h,0],axis?[0,h,-w]:[-w,h,0],stem);
 }
 for(let i=0;i<6;i++)for(const side of[-1,1]){
  const y=.75+i*.042,x=side*(.045-i*.004),z=i%2?.028:-.028;
  leaf([0,y-.018,0],[x,y+.02,z],[x*.7,y+.072,z*.6],[0,y+.043,0],i>3?tip:ear);
  leaf([0,y-.018,0],[z,y+.02,x],[z*.6,y+.072,x*.7],[0,y+.043,0],ear);
 }
 for(const side of[-1,1])leaf([0,.25,0],[side*.16,.36,.015],[side*.31,.49,0],[side*.08,.34,-.015],stem);
 const g=new T.InstancedBufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setAttribute('normal',new T.Float32BufferAttribute(normals,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));
 const bases:number[]=[],shapes:number[]=[],tints:number[]=[];
 const patches=[[-45,35,36,52],[48,40,38,57],[0,115,100,57],[-112,-6,42,65],[111,0,45,68],[-23,52,18,29],[24,51,18,30],[-64,10,23,28],[67,12,25,29],[-78,39,24,35],[77,75,26,28]];
 const density=innerWidth<700?2.1:4.6;
 for(const[cx,cz,w,d]of patches){
  for(let i=0;i<w*d*density;i++){
   const x=cx+(random()-.5)*w,z=cz+(random()-.5)*d;
   if(Math.hypot(x/35,(z-47)/22)<1)continue;
   const edge=Math.abs((x-cx)/w)*2+.07*Math.sin(z*.42)+.04*Math.cos(x*.57);
   if(edge>.98||Math.abs(x)<3.5||Math.abs(Math.sin((z-cz)*.15+(x-cx)*.025))<.035)continue;
   bases.push(x,ground(x,z)+.035,z);shapes.push(.65+(.5+.5*Math.sin(x*.17+Math.sin(z*.13)))*.55+random()*.45,random()*Math.PI*2,random()*6.28);
   const tint=new T.Color().setHSL(.115+random()*.035,.32+random()*.15,.4+random()*.2);tints.push(tint.r,tint.g,tint.b);
  }
 }
 // Fill the entire former lake with a continuous, uneven golden wheat meadow.
 for(let i=0;i<(innerWidth<700?6500:15500);i++){
  const x=(random()-.5)*70,z=25+random()*44;
  if(Math.hypot(x/35,(z-47)/22)>.99)continue;
  const cluster=.5+.5*Math.sin(x*.16+Math.sin(z*.12)*1.2);
  bases.push(x,ground(x,z)+.035,z);
  shapes.push(.68+cluster*.8+random()*.4,random()*6.28,random()*6.28);
  const c=new T.Color().setHSL(.12+random()*.025,.32+random()*.12,.36+cluster*.12+random()*.08);tints.push(c.r,c.g,c.b);
 }
 g.setAttribute('aBase',new T.InstancedBufferAttribute(new Float32Array(bases),3));g.setAttribute('aShape',new T.InstancedBufferAttribute(new Float32Array(shapes),3));g.setAttribute('aTint',new T.InstancedBufferAttribute(new Float32Array(tints),3));g.instanceCount=bases.length/3;
 const uniforms={time:{value:0},moonPosition:{value:new T.Vector3(80,65,-80)}};
 const material=new T.ShaderMaterial({side:T.DoubleSide,uniforms,vertexColors:true,vertexShader:`
  attribute vec3 aBase,aShape,aTint;uniform float time;uniform vec3 moonPosition;
  varying vec3 vColor,vNormal,vWorld;varying float vHeight;
  void main(){
   float cs=cos(aShape.y),sn=sin(aShape.y),h=position.y;
   vec3 local=vec3(position.x*cs-position.z*sn,h*aShape.x,position.x*sn+position.z*cs);
   // A broad travelling gust passes, then the crop settles for a quiet interval.
   float phase=mod(time-dot(aBase.xz,vec2(.86,.5))/5.,18.);
   float envelope=smoothstep(0.,1.2,phase)*(1.-smoothstep(4.,7.,phase));
   float gust=sin(time*.75+aBase.x*.07+aBase.z*.09)*.035;
   gust+=envelope*(.24+.16*sin(dot(aBase.xz,vec2(.24,.14))-time*1.9));
   gust+=sin(time*1.5+aShape.z)*.018;
   local.x+=gust*h*h;local.z+=gust*.55*h*h;local.y-=abs(gust)*.16*h*h;
   vec3 world=aBase+local;vWorld=world;vHeight=h;
   vec3 rotated=vec3(normal.x*cs-normal.z*sn,normal.y,normal.x*sn+normal.z*cs);
   vNormal=normalize(vec3(rotated.x,rotated.y-(rotated.x+rotated.z*.55)*2.*gust*h,rotated.z));
   vColor=color*mix(vec3(.85),aTint*2.4,.3);
   gl_Position=projectionMatrix*viewMatrix*vec4(world,1.);
  }`,fragmentShader:`
  uniform vec3 moonPosition;uniform float time;varying vec3 vColor,vNormal,vWorld;varying float vHeight;
  ${CLOUD_LIGHT_GLSL}
  void main(){
   vec3 l=normalize(moonPosition-vWorld),eye=normalize(cameraPosition-vWorld),n=normalize(vNormal);
   float diffuse=abs(dot(n,l)),rim=pow(1.-abs(dot(n,eye)),2.);
   float shimmer=pow(abs(dot(n,normalize(l+eye))),18.);
   float moonPatch=cloudTransmission(vWorld,moonPosition,time);
   vec3 c=vColor*(.58+.46*diffuse)*(.6+.4*smoothstep(0.,.7,vHeight))*moonPatch;
   c+=vec3(.22,.17,.06)*(rim*.23+shimmer*.28)*smoothstep(.65,1.,vHeight);
   float distanceToEye=length(cameraPosition-vWorld);
   c=mix(c,vec3(.055,.1,.15),1.-exp(-distanceToEye*distanceToEye*.000014));
   gl_FragColor=vec4(c,1.);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 const plants=new T.Mesh(g,material);plants.frustumCulled=false;scene.add(plants);
 return{count:g.instanceCount,update:(seconds:number,moon:T.Vector3)=>{uniforms.time.value=seconds;uniforms.moonPosition.value.copy(moon);}};
}
