import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {CLOUD_LIGHT_GLSL} from './cloud-light';

/** Crossed, segmented stems and individual grains remain volumetric from the side. */
export function buildFields(scene:T.Scene,ground:(x:number,z:number)=>number){
 const mobile=innerWidth<700||matchMedia('(pointer:coarse)').matches;
 let seed=7219;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const vertices:number[]=[],normals:number[]=[],colors:number[]=[];
 function triangle(a:number[],b:number[],c:number[],color:T.Color){
  const n=new T.Vector3().crossVectors(new T.Vector3().fromArray(b).sub(new T.Vector3().fromArray(a)),new T.Vector3().fromArray(c).sub(new T.Vector3().fromArray(a))).normalize();
  vertices.push(...a,...b,...c);for(let i=0;i<3;i++){normals.push(n.x,n.y,n.z);colors.push(color.r,color.g,color.b);}
 }
 function leaf(a:number[],b:number[],c:number[],d:number[],color:T.Color){triangle(a,b,c,color);triangle(a,c,d,color);}
 const stem=new T.Color('#728575'),ear=new T.Color('#d0b871'),tip=new T.Color('#e3cf8c');
 for(let axis=0;axis<2;axis++)for(let segment=0;segment<3;segment++){
  const y=segment*.27,h=y+.27,w=.014;
  leaf(axis?[0,y,-w]:[-w,y,0],axis?[0,y,w]:[w,y,0],axis?[0,h,w]:[w,h,0],axis?[0,h,-w]:[-w,h,0],stem);
 }
 for(let i=0;i<6;i++)for(const side of[-1,1]){
  const y=.75+i*.042,x=side*(.045-i*.004),z=i%2?.028:-.028;
  leaf([0,y-.018,0],[x,y+.02,z],[x*.7,y+.072,z*.6],[0,y+.043,0],i>3?tip:ear);
  leaf([0,y-.018,0],[z,y+.02,x],[z*.6,y+.072,x*.7],[0,y+.043,0],ear);
 }
 for(const side of[-1,1])leaf([0,.25,0],[side*.16,.36,.015],[side*.31,.49,0],[side*.08,.34,-.015],stem);
 const g=new T.InstancedBufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setAttribute('normal',new T.Float32BufferAttribute(normals,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));
 const bases:number[]=[],shapes:number[]=[],tints:number[]=[];
 const patches=[[-45,35,36,52],[48,40,38,57],[0,115,100,57],[-112,-6,42,65],[111,0,45,68],[-23,52,18,29],[24,51,18,30],[-64,10,23,28],[67,12,25,29],[-78,39,24,35],[77,75,26,28]];
 const density=mobile?2.1:4.6;
 for(const[cx,cz,w,d]of patches){
  for(let i=0;i<w*d*density;i++){
   const x=cx+(random()-.5)*w,z=cz+(random()-.5)*d;
   if(Math.hypot(x/35,(z-47)/22)<1)continue;
   const edge=Math.abs((x-cx)/w)*2+.07*Math.sin(z*.42)+.04*Math.cos(x*.57);
   if(edge>.98||Math.abs(x)<3.5||Math.abs(Math.sin((z-cz)*.15+(x-cx)*.025))<.035)continue;
   bases.push(x,ground(x,z)+.035,z);shapes.push(.48+(.5+.5*Math.sin(x*.17+Math.sin(z*.13)))*.85+random()*.62,random()*Math.PI*2,random()*6.28);
   const tint=new T.Color().setHSL(.115+random()*.035,.32+random()*.15,.4+random()*.2);tints.push(tint.r,tint.g,tint.b);
  }
 }
 // Fill the entire former lake with a continuous, uneven golden wheat meadow.
 for(let i=0;i<(mobile?6500:15500);i++){
  const x=(random()-.5)*70,z=25+random()*44;
  if(Math.hypot(x/35,(z-47)/22)>.99)continue;
  const cluster=.5+.5*Math.sin(x*.16+Math.sin(z*.12)*1.2);
  bases.push(x,ground(x,z)+.035,z);
  shapes.push(.48+cluster*1.05+random()*.65,random()*6.28,random()*6.28);
  const c=new T.Color().setHSL(.12+random()*.025,.32+random()*.12,.36+cluster*.12+random()*.08);tints.push(c.r,c.g,c.b);
 }
 // Foreground plants use rounded individual kernels, segmented stems, curved
 // leaves and awns. Keep the lighter crossed geometry in the broad distance.
 const parts:T.BufferGeometry[]=[];
 function painted(part:T.BufferGeometry,c:T.Color){
  const flat=part.index?part.toNonIndexed():part;
  flat.deleteAttribute('uv');
  const cs=new Float32Array(flat.attributes.position.count*3);
  for(let i=0;i<cs.length;i+=3){cs[i]=c.r;cs[i+1]=c.g;cs[i+2]=c.b;}
  flat.setAttribute('color',new T.BufferAttribute(cs,3));parts.push(flat);if(flat!==part)part.dispose();
 }
 const stalk=new T.CylinderGeometry(.009,.015,.82,6,4);stalk.translate(0,.41,0);painted(stalk,stem);
 for(let row=0;row<6;row++)for(const side of[-1,1]){
  const kernel=new T.OctahedronGeometry(1,0);kernel.scale(.028-row*.0015,.045,.024);
  kernel.rotateZ(-side*.38);kernel.translate(side*(.024-row*.002),.77+row*.043,row%2?.012:-.012);painted(kernel,row>3?tip:ear);
  const awn=new T.BufferGeometry();const y=.8+row*.043,x=side*(.046-row*.002);
  awn.setAttribute('position',new T.Float32BufferAttribute([x,y,0,x+side*.003,y,0,x+side*.038,y+.13,0],3));awn.computeVertexNormals();painted(awn,tip);
 }
 for(let row=0;row<3;row++){
  const y=.18+row*.17,side=row%2?-1:1,blade=new T.BufferGeometry();
  blade.setAttribute('position',new T.Float32BufferAttribute([0,y,0,side*.12,y+.1,-.018,side*.23,y+.14,0,0,y,0,side*.23,y+.14,0,side*.12,y+.1,.018,side*.12,y+.1,.018,side*.23,y+.14,0,side*.32,y+.1,0],3));
  blade.computeVertexNormals();blade.rotateY(row*2.1);painted(blade,stem);
 }
 const detailed=mergeGeometries(parts,false)!;for(const part of parts)part.dispose();
 const fine=new T.InstancedBufferGeometry();for(const name of ['position','normal','color'])fine.setAttribute(name,detailed.getAttribute(name));
 const farBase:number[]=[],farShape:number[]=[],farTint:number[]=[],fineBase:number[]=[],fineShape:number[]=[],fineTint:number[]=[];
 for(let i=0;i<bases.length;i+=3){
  const close=Math.abs(bases[i])<48&&bases[i+2]>23&&bases[i+2]<90&&(i/3)%(mobile?6:3)===0;
  (close?fineBase:farBase).push(bases[i],bases[i+1],bases[i+2]);
  (close?fineShape:farShape).push(shapes[i],shapes[i+1],shapes[i+2]);
  (close?fineTint:farTint).push(tints[i],tints[i+1],tints[i+2]);
 }
 for(const[geometry,bs,ss,ts]of [[g,farBase,farShape,farTint],[fine,fineBase,fineShape,fineTint]]as const){
  geometry.setAttribute('aBase',new T.InstancedBufferAttribute(new Float32Array(bs),3));geometry.setAttribute('aShape',new T.InstancedBufferAttribute(new Float32Array(ss),3));geometry.setAttribute('aTint',new T.InstancedBufferAttribute(new Float32Array(ts),3));geometry.instanceCount=bs.length/3;
 }
 const uniforms={time:{value:0},moonPosition:{value:new T.Vector3(80,65,-80)}};
 const material=new T.ShaderMaterial({side:T.DoubleSide,uniforms,vertexColors:true,vertexShader:`
  attribute vec3 aBase,aShape,aTint;uniform float time;uniform vec3 moonPosition;
  varying vec3 vColor,vNormal,vWorld;varying float vHeight;
  void main(){
   float cs=cos(aShape.y),sn=sin(aShape.y),h=position.y;
   vec3 local=vec3(position.x*cs-position.z*sn,h*aShape.x,position.x*sn+position.z*cs);
   float lean=sin(aShape.z)*.075;
   local.x+=lean*h*h;local.z+=cos(aShape.z)*.04*h*h;
   // A broad travelling gust passes, then the crop settles for a quiet interval.
   float phase=mod(time-dot(aBase.xz,vec2(.86,.5))/5.,18.);
   float envelope=smoothstep(0.,1.2,phase)*(1.-smoothstep(4.,7.,phase));
   float gust=sin(time*.75+aBase.x*.07+aBase.z*.09)*.035;
   gust+=envelope*(.24+.16*sin(dot(aBase.xz,vec2(.24,.14))-time*1.9));
   gust+=sin(time*1.5+aShape.z)*.018;
   local.x+=gust*h*h;local.z+=gust*.55*h*h;local.y-=abs(gust)*.16*h*h;
   vec3 world=aBase+local;vWorld=world;vHeight=h;
   vec3 rotated=vec3(normal.x*cs-normal.z*sn,normal.y/aShape.x,normal.x*sn+normal.z*cs);
   vNormal=normalize(vec3(rotated.x,rotated.y-(rotated.x+rotated.z*.55)*2.*gust*h,rotated.z));
   vColor=color*mix(vec3(.85),aTint*2.4,.3);
   gl_Position=projectionMatrix*viewMatrix*vec4(world,1.);
  }`,fragmentShader:`
  uniform vec3 moonPosition;uniform float time;varying vec3 vColor,vNormal,vWorld;varying float vHeight;
  ${CLOUD_LIGHT_GLSL}
  void main(){
   vec3 l=normalize(moonPosition-vWorld),eye=normalize(cameraPosition-vWorld),n=normalize(vNormal);
   float diffuse=abs(dot(n,l)),rim=pow(1.-abs(dot(n,eye)),2.);
   float shimmer=pow(abs(dot(n,normalize(l+eye))),18.);
   float moonPatch=cloudTransmission(vWorld,moonPosition,time);
   vec3 c=vColor*(.58+.46*diffuse)*(.6+.4*smoothstep(0.,.7,vHeight))*moonPatch;
   c+=vec3(.22,.17,.06)*(rim*.23+shimmer*.28)*smoothstep(.65,1.,vHeight);
   float distanceToEye=length(cameraPosition-vWorld);
   c=mix(c,vec3(.055,.1,.15),1.-exp(-distanceToEye*distanceToEye*.000014));
   gl_FragColor=vec4(c,1.);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 const plants=new T.Mesh(g,material);plants.frustumCulled=false;scene.add(plants);
 const finePlants=new T.Mesh(fine,material);finePlants.frustumCulled=false;scene.add(finePlants);
 return{count:g.instanceCount+fine.instanceCount,update:(seconds:number,moon:T.Vector3)=>{uniforms.time.value=seconds;uniforms.moonPosition.value.copy(moon);}};
}
