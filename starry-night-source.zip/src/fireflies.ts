import * as T from 'three';

/** A single draw call; independently drifting and blinking lights above meadows. */
export function buildFireflies(scene:T.Scene,ground:(x:number,z:number)=>number){
 let seed=188906;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const patches=[[39,48],[-47,31],[65,15],[-65,14],[78,72],[-87,69],[-22,108],[32,111],[51,80],[-85,26],[51,36],[59,22],[-19,44],[0,40],[18,48],[-15,60],[15,62]];
 const count=innerWidth<700?220:540,positions:number[]=[],phases:number[]=[],colors:number[]=[];
 for(let i=0;i<count;i++){
  const [cx,cz]=patches[i%patches.length],x=cx+(random()-.5)*22,z=cz+(random()-.5)*22;
  positions.push(x,ground(x,z)+1.7+random()*2.2,z);phases.push(random()*6.28,.55+random()*.75,random());
  const c=new T.Color(i%3?'#c1d66c':'#edcc7a');colors.push(c.r,c.g,c.b);
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('aPhase',new T.Float32BufferAttribute(phases,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));
 const uniforms={time:{value:0}};
 const material=new T.ShaderMaterial({uniforms,vertexColors:true,transparent:true,depthWrite:false,blending:T.AdditiveBlending,vertexShader:`
  attribute vec3 aPhase;uniform float time;varying vec3 vColor;varying float vLight;
  void main(){
   float t=time*aPhase.y;
   vec3 p=position+vec3(sin(t*.53+aPhase.x)*1.4,sin(t*.8+aPhase.x)*.38,cos(t*.41+aPhase.x)*1.1);
   vec4 mv=modelViewMatrix*vec4(p,1.);
   gl_Position=projectionMatrix*mv;gl_PointSize=clamp((8.+aPhase.z*5.)*90./max(1.,-mv.z),1.4,17.);
   vLight=.12+.88*pow(.5+.5*sin(t*2.3+aPhase.x*3.),3.);vColor=color;
  }`,fragmentShader:`
  varying vec3 vColor;varying float vLight;
  void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;
   float halo=exp(-r*r*20.)*.4,core=exp(-r*r*160.);
   gl_FragColor=vec4(vColor*(.7+core*1.4),(halo+core*.65)*vLight);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 const lights=new T.Points(g,material);lights.frustumCulled=false;lights.renderOrder=3;scene.add(lights);
 return{count,update:(seconds:number)=>{uniforms.time.value=seconds;}};
}
