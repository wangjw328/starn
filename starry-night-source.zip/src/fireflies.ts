import * as T from 'three';

/** A single draw call; independently drifting and blinking lights above meadows. */
export function buildFireflies(scene:T.Scene,ground:(x:number,z:number)=>number){
 let seed=188906;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const patches=[[39,48],[-47,31],[65,15],[-65,14],[78,72],[-87,69],[-22,108],[32,111],[51,80],[-85,26],[51,36],[59,22],[-19,44],[0,40],[18,48],[-15,60],[15,62]];
 const count=innerWidth<700?260:640,positions:number[]=[],phases:number[]=[],colors:number[]=[],flights:number[]=[];
 for(let i=0;i<count;i++){
  const [cx,cz]=patches[i%patches.length],x=cx+(random()-.5)*22,z=cz+(random()-.5)*22;
  const rx=5+random()*12,rz=5+random()*11;
  let floor=ground(x,z);for(let j=0;j<12;j++){const a=j*Math.PI/6;floor=Math.max(floor,ground(x+Math.cos(a)*rx*1.25,z+Math.sin(a)*rz*1.25));}
  positions.push(x,floor+1.4+random()*2.2,z);phases.push(random()*6.28,.55+random()*.75,random());flights.push(rx,rz,random()*6.28,.65+random()*.7);
  const c=new T.Color(i%3?'#c1d66c':'#edcc7a');colors.push(c.r,c.g,c.b);
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('aPhase',new T.Float32BufferAttribute(phases,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));
 g.setAttribute('aFlight',new T.Float32BufferAttribute(flights,4));
 const uniforms={time:{value:0}};
 const material=new T.ShaderMaterial({uniforms,vertexColors:true,transparent:true,depthWrite:false,blending:T.AdditiveBlending,vertexShader:`
  attribute vec3 aPhase;attribute vec4 aFlight;uniform float time;varying vec3 vColor;varying float vLight;
  void main(){
   float t=time*aPhase.y;
   // Broad smooth loops with independent turning and gentle height changes.
   // Each insect stays in its meadow territory, with no random frame jumps.
   float orbit=t*.115*aFlight.w+aPhase.x,turn=aFlight.z+.22*sin(t*.047+aPhase.x);
   vec2 drift=vec2(sin(orbit)*aFlight.x,cos(orbit*.91+aPhase.x*.25)*aFlight.y);
   drift+=vec2(sin(t*.19+aPhase.x),cos(t*.17+aPhase.x))*.9;
   vec2 flow=mat2(cos(turn),sin(turn),-sin(turn),cos(turn))*drift;
   vec3 p=position+vec3(flow.x,.9*sin(t*.23+aPhase.x)+.35*sin(t*.41+aPhase.x*2.),flow.y);
   vec4 mv=modelViewMatrix*vec4(p,1.);
   gl_Position=projectionMatrix*mv;gl_PointSize=clamp((8.+aPhase.z*5.)*90./max(1.,-mv.z),1.4,17.);
   vLight=.12+.88*pow(.5+.5*sin(t*2.3+aPhase.x*3.),3.);vColor=color;
  }`,fragmentShader:`
  varying vec3 vColor;varying float vLight;
  void main(){float r=length(gl_PointCoord-.5);if(r>.5)discard;
   float halo=exp(-r*r*20.)*.4,core=exp(-r*r*160.);
   gl_FragColor=vec4(vColor*(.7+core*1.4),(halo+core*.65)*vLight);
   #include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 const lights=new T.Points(g,material);lights.frustumCulled=false;lights.renderOrder=3;scene.add(lights);
 return{count,update:(seconds:number)=>{uniforms.time.value=seconds;}};
}

/** Warm, clearly visible companions hover beside the optional camera tour. */
export function buildTourFireflies(scene:T.Scene){
 const count=14,frame=new T.Group(),sprites:T.Sprite[]=[],phases:number[]=[],bases:T.Vector3[]=[];
 const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
 const ctx=canvas.getContext('2d')!,glow=ctx.createRadialGradient(32,32,0,32,32,32);
 glow.addColorStop(0,'rgba(255,255,219,1)');glow.addColorStop(.13,'rgba(255,235,120,1)');
 glow.addColorStop(.3,'rgba(213,236,95,.65)');glow.addColorStop(.65,'rgba(180,215,73,.12)');glow.addColorStop(1,'rgba(180,215,73,0)');
 ctx.fillStyle=glow;ctx.fillRect(0,0,64,64);const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
 let seed=281889;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 for(let i=0;i<count;i++){
  const material=new T.SpriteMaterial({map:texture,color:i%3?'#e4f39b':'#ffe29b',transparent:true,depthWrite:false,depthTest:true,blending:T.AdditiveBlending,toneMapped:false});
  const sprite=new T.Sprite(material);sprite.renderOrder=8;
  // x/y store screen-edge lanes, z stores depth; the middle 75% stays clear.
  const base=new T.Vector3((i%2?1:-1)*(.84+random()*.09),-.55+random(),-5-random()*5);
  sprite.scale.setScalar(.09+random()*.05);frame.add(sprite);sprites.push(sprite);bases.push(base);phases.push(random()*Math.PI*2);
 }
 frame.visible=false;scene.add(frame);let activeLastFrame=false,lastTime=0,fade=0;
 return{count,update:(dt:number,seconds:number,camera:T.PerspectiveCamera,active:boolean)=>{
  if(active&&(!activeLastFrame||frame.position.distanceToSquared(camera.position)>400)){frame.position.copy(camera.position);frame.quaternion.copy(camera.quaternion);}
  const step=lastTime?Math.min(.25,Math.max(0,seconds-lastTime)):dt;lastTime=seconds;activeLastFrame=active;
  fade=T.MathUtils.damp(fade,active?1:0,3,step);frame.visible=fade>.01;if(!frame.visible)return;
  frame.position.copy(camera.position);frame.quaternion.copy(camera.quaternion);
  const halfHeight=Math.tan(camera.fov*Math.PI/360);
  for(let i=0;i<count;i++){
   const phase=phases[i],base=bases[i],sprite=sprites[i];
   const depth=-base.z+.2*Math.sin(seconds*.45+phase);
   sprite.position.set((base.x+.018*Math.sin(seconds*.65+phase))*depth*halfHeight*camera.aspect,(base.y+.06*Math.sin(seconds*.83+phase))*depth*halfHeight,-depth);
   sprite.material.opacity=fade*(.4+.35*(.5+.5*Math.sin(seconds*1.6+phase)));
  }
 }};
}
