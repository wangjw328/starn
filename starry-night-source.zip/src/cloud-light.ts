/** Shared projected cloud density for terrain, brushwork and wheat. */
export const CLOUD_LIGHT_GLSL=`
 float cloudTransmission(vec3 world,vec3 moon,float seconds){
  vec3 light=normalize(moon-world);
  vec2 q=world.xz+light.xz*(72.-world.y)/max(.25,light.y);
  float broad=sin(q.x*.033+q.y*.018-seconds*.085);
  float curled=sin(q.y*.047-q.x*.014+seconds*.052+sin(q.x*.025+seconds*.035)*1.3);
  float fine=sin(q.x*.074+q.y*.053-seconds*.13)*.22;
  float density=smoothstep(-.65,.95,broad*.6+curled*.55+fine);
  return .38+.62*(1.-density);
 }
`;
