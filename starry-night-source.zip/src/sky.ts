import * as T from 'three';

type Brush={stroke:(p:T.Vector3,t:T.Vector3,n:T.Vector3,length:number,width:number,color:T.Color,opacity?:number,motion?:number)=>void};
const TAU=Math.PI*2;
const wrap=(x:number)=>x-Math.floor(x);

/** One periodic colour/direction field covers the whole hemisphere, including the pole. */
export async function buildSurroundSky(brush:Brush){
 const response=await fetch('./assets/strokes.bin');
 if(!response.ok)throw new Error('原画笔触数据未能加载。');
 const source=new Float32Array(await response.arrayBuffer()),w=320,h=208,channels=5;
 let grid=new Float32Array(w*h*channels),counts=new Uint16Array(w*h);
 for(let j=0;j<source.length;j+=7){
  if(source[j+1]>.64)continue;
  const x=Math.min(w-1,Math.floor(source[j]*w)),y=Math.min(h-1,Math.floor(source[j+1]/.64*h)),cell=y*w+x,k=cell*channels,a=source[j+2]*2;
  grid[k]+=source[j+4];grid[k+1]+=source[j+5];grid[k+2]+=source[j+6];grid[k+3]+=Math.cos(a);grid[k+4]+=Math.sin(a);counts[cell]++;
 }
 for(let i=0;i<counts.length;i++)if(counts[i])for(let c=0;c<channels;c++)grid[i*channels+c]/=counts[i];
 // Fill sparse sampling holes without blurring the populated paint directions.
 for(let pass=0;pass<8;pass++){
  const next=grid.slice(),filled=counts.slice();let empty=0;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
   const i=y*w+x;if(counts[i])continue;let n=0;
   for(const[dx,dy]of[[-1,0],[1,0],[0,-1],[0,1]]){
    const xx=Math.max(0,Math.min(w-1,x+dx)),yy=Math.max(0,Math.min(h-1,y+dy)),j=yy*w+xx;
    if(!counts[j])continue;n++;for(let c=0;c<channels;c++)next[i*channels+c]+=grid[j*channels+c];
   }
   if(n){for(let c=0;c<channels;c++)next[i*channels+c]/=n;filled[i]=1;}else empty++;
  }
  grid=next;counts=filled;if(!empty)break;
 }
 const a=new Float32Array(channels),b=new Float32Array(channels),cap=new Float32Array(channels);
 function sample(u:number,v:number,out:Float32Array){
  // Keep the painting’s right-hand mountain silhouette out of the surrounding sky.
  v-=.14*T.MathUtils.smoothstep(u,.78,.94)*T.MathUtils.smoothstep(v,.45,.6);
  const x=T.MathUtils.clamp(u,0,1)*(w-1),y=T.MathUtils.clamp(v/.64,0,1)*(h-1),ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy;
  out.fill(0);
  for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){
   const k=(Math.min(h-1,iy+dy)*w+Math.min(w-1,ix+dx))*channels,weight=(dx?fx:1-fx)*(dy?fy:1-fy);
   for(let c=0;c<channels;c++)out[c]+=grid[k+c]*weight;
  }
 }
 const center=new T.Vector3(0,12,0),radius=224;
 // Broad continuous relief follows curling cloud ridges rather than a sphere.
 // It closes around the azimuth and becomes independent of it at the zenith.
 function relief(theta:number,el:number,phase=0){
  const ce=Math.cos(el);
  return ce*ce*(26*Math.sin(theta*4+el*5+phase)+
   17*Math.cos(theta*7-el*6+phase*.6))+12*Math.sin(el*7+phase);
 }
 let pigmentElevation=0;
 function field(theta:number,elevation:number){
  pigmentElevation=elevation;
  // Four overlapping traversals of the original paint field, with matched endpoint values.
  const phase=wrap(theta/(Math.PI/2)+.38/.88),q=phase*.88;
  const v=.6*(.5+.5*Math.cos(elevation*4));
  sample(q+.12,v,a);
  if(q>.76){sample(q-.76,v,b);const blend=T.MathUtils.smoothstep(q,.76,.88);for(let c=0;c<channels;c++)a[c]+=(b[c]-a[c])*blend;}
  // At the zenith, use a continuous planar swirl rather than an azimuth singularity.
  const ce=Math.cos(elevation),twist=theta+ce*6;
  sample(.5+.34*ce*Math.cos(twist),.32+.25*ce*Math.sin(twist),cap);
  const overhead=T.MathUtils.smoothstep(elevation,.95,1.4);
  for(let c=0;c<channels;c++)a[c]+=(cap[c]-a[c])*overhead;
  return overhead;
 }
 function flow(theta:number,el:number,angle:number,overhead:number){
  // Transform the painting's tangent by the inverse projection Jacobian.
  // Multiplying by the elevation derivative flattened the circular vortices.
  const dv=-1.2*Math.sin(el*4),safeDv=(dv<0?-1:1)*Math.max(.3,Math.abs(dv));
  const x=Math.cos(angle)*Math.cos(el)/(.88/(Math.PI/2));
  const y=Math.sin(angle)*(1000/792)/safeDv;
  tangent.copy(east).multiplyScalar(x*(1-overhead)+overhead).addScaledVector(north,y*(1-overhead)+overhead*.32).normalize();
 }
 let seed=4291889;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const colour=new T.Color(),n=new T.Vector3(),east=new T.Vector3(),north=new T.Vector3(),tangent=new T.Vector3(),point=new T.Vector3(),normalForVolume=new T.Vector3();
 // Enrich the sampled pigments while retaining their luminance and brush detail.
 function pigment(){
  const r=a[0],g=a[1],b=a[2],luma=r*.2126+g*.7152+b*.0722;
  const yellow=T.MathUtils.smoothstep(Math.min(r,g)-b,.025,.2);
  const cloudWhite=(1-yellow)*T.MathUtils.smoothstep(luma,.22,.52)*.42;
  // Expand the cloud/dark-blue separation before tone mapping, rather than
  // lifting every shadow with global exposure. Warm paint keeps a golden hue.
  const value=.88+T.MathUtils.smoothstep(luma,.1,.4)*.48;
  colour.setRGB(
   T.MathUtils.lerp(Math.max(0,luma+(r-luma)*1.16)*value+yellow*.06,.72,cloudWhite),
   T.MathUtils.lerp(Math.max(0,luma+(g-luma)*1.16)*value*(1-.035*yellow),.76,cloudWhite),
   T.MathUtils.lerp(Math.max(0,luma+(b-luma)*1.16)*value*(1-yellow*.38),.8,cloudWhite),
   T.LinearSRGBColorSpace
  );
  // Soften only the dense, dark cobalt paint. Apply the same pigment treatment
  // at every depth so the middle cloud bands cannot become a dark blue stripe.
  const darkBlue=.2*T.MathUtils.smoothstep(b-Math.max(r,g),.012,.09)*
   (1-T.MathUtils.smoothstep(luma,.12,.3));
  colour.r=T.MathUtils.lerp(colour.r,.16,darkBlue);
  colour.g=T.MathUtils.lerp(colour.g,.26,darkBlue);
  colour.b=T.MathUtils.lerp(colour.b,.37,darkBlue);
  // Unify the stacked upper cobalt/black marks into a softer blue-grey value.
  // Keep bright clouds and golden stars intact, with a feathered elevation mask.
  const upper=T.MathUtils.smoothstep(pigmentElevation,.48,.72)*(1-T.MathUtils.smoothstep(pigmentElevation,1.15,1.4));
  const lift=upper*(1-yellow)*(1-T.MathUtils.smoothstep(luma,.1,.28))*.28;
  colour.r=T.MathUtils.lerp(colour.r,.17,lift);colour.g=T.MathUtils.lerp(colour.g,.25,lift);colour.b=T.MathUtils.lerp(colour.b,.34,lift);
 }
 const perLayer=480000,layers=1;
 for(let layer=0;layer<layers;layer++)for(let i=0;i<perLayer;i++){
  const theta=(random()-.5)*TAU,elevation=Math.asin(-.085+random()*1.085),ce=Math.cos(elevation),se=Math.sin(elevation);
  const overhead=field(theta,elevation),angle=.5*Math.atan2(a[4],a[3]);
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);
  east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  flow(theta,elevation,angle,overhead);
  const lightPaint=T.MathUtils.smoothstep(a[0]*.2126+a[1]*.7152+a[2]*.0722,.14,.48);
  const r=radius+relief(theta,elevation)-lightPaint*15+(random()-.5)*5;
  point.copy(n).multiplyScalar(r).add(center);
  // Tilt the strokes with the sculpted surface, rather than leaving all of
  // them tangent to an invisible perfect globe.
  const drTheta=ce*ce*(104*Math.cos(theta*4+elevation*5)-119*Math.sin(theta*7-elevation*6));
  const drEl=-2*ce*se*(26*Math.sin(theta*4+elevation*5)+17*Math.cos(theta*7-elevation*6))+
   ce*ce*(130*Math.cos(theta*4+elevation*5)+102*Math.sin(theta*7-elevation*6))+84*Math.cos(elevation*7);
  n.addScaledVector(east,-drTheta/(r*Math.max(.15,ce))).addScaledVector(north,-drEl/r).normalize();
  tangent.addScaledVector(n,-tangent.dot(n)).normalize();
  pigment();
  brush.stroke(point,tangent,n,2.3+random()*1.7,.23+random()*.16,colour,1,1);
 }
 // Broken outer cloud banks occupy different depths and curl independently.
 // These remain traversable; the continuous far field is still behind them.
 const outerCount=150000;
 for(let i=0;i<outerCount;i++){
  const bank=i<75000?0:1,theta=(random()-.5)*TAU,el=Math.asin(.02+random()*.98),ce=Math.cos(el),se=Math.sin(el);
  const overhead=field(theta,el),angle=.5*Math.atan2(a[4],a[3]);pigment();
  const r=(bank?835:655)+relief(theta,el,1.2+bank)*1.5+(random()-.5)*90;
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);
  east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  flow(theta,el,angle,overhead);tangent.addScaledVector(n,.3*Math.sin(theta*4+el*9+bank)).normalize();
  point.copy(n).multiplyScalar(r).add(center);
  normalForVolume.copy(n).addScaledVector(north,.35*Math.sin(theta*3+el*8+bank)).normalize();
  const density=.5+.5*Math.sin(theta*4+el*10+bank*2+Math.sin(theta*3));
  brush.stroke(point,tangent,normalForVolume,(1+random()*1.4)*r/radius,(.15+random()*.18)*r/radius,colour,.18+.58*T.MathUtils.smoothstep(density,.25,.85),2);
 }
 // A 140-metre-deep cloud volume sits in front of and through the distant field.
 // Shared angular coordinates preserve the large painting swirls from a distance;
 // radial separation, rolled normals and curled depth create parallax inside them.
 const volumeCount=240000;
 for(let i=0;i<volumeCount;i++){
  const theta=(random()-.5)*TAU,el=.12+random()*1.38,ce=Math.cos(el),se=Math.sin(el);
  const overhead=field(theta,el),angle=.5*Math.atan2(a[4],a[3]);pigment();
  const depth=random();
  // Two sparse, rippled middle bands bridge the main painted sky and the
  // distant continuation. Their depth varies continuously, avoiding flat shells.
  const middle=i>=150000;
  const r=(middle?(i<195000?335:475)+(depth-.5)*62:
   i<100000?118+depth*145:265+depth*275)+
   (middle?20:9)*Math.sin(theta*5+el*13+depth*8);
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);
  east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  flow(theta,el,angle,overhead);tangent.addScaledVector(n,.22*Math.sin(el*15+theta*4+depth*8)).normalize();
  point.copy(n).multiplyScalar(r).add(center);
  normalForVolume.copy(n).addScaledVector(north,.5*Math.sin(depth*9+theta*3)).normalize();
  const band=.5+.5*Math.sin(theta*3+el*11+Math.sin(theta*5)*.65);
  const opacity=middle?.24+.48*T.MathUtils.smoothstep(band,.25,.8):.75+random()*.25;
  brush.stroke(point,tangent,normalForVolume,(.7+random()*1.4)*r/radius,(.13+random()*.17)*r/radius,colour,opacity,2);
 }
 // Distant continuation stays beyond the entire flyable space, so crossing
 // the foreground cloud never reveals a blank background.
 const distantCount=270000;
 for(let i=0;i<distantCount;i++){
  const theta=(random()-.5)*TAU,el=Math.asin(-.12+random()*1.12),ce=Math.cos(el),se=Math.sin(el);
  const overhead=field(theta,el),angle=.5*Math.atan2(a[4],a[3]);pigment();
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  flow(theta,el,angle,overhead);
  const r=1040+relief(theta,el,2.8)*1.8+(random()-.5)*45;
  point.copy(n).multiplyScalar(r).add(center);
  brush.stroke(point,tangent,n,(4+random()*3)*r/700,(1.1+random()*.7)*r/700,colour,1,1);
 }
 // Landmarks and solid stars now occupy the same enclosing field as the paint.
 // Re-establish the painting's two characteristic curling cloud ribbons with
 // connected strokes, so their silhouettes survive the distant brush texture.
 const ribbons=[
  {points:[[.27,.29],[.4,.19],[.55,.19],[.625,.28],[.61,.365],[.54,.405],[.47,.35],[.47,.275],[.515,.285],[.54,.345]],count:26000,width:.115},
  {points:[[.37,.45],[.52,.455],[.635,.405],[.72,.425],[.75,.48],[.71,.525],[.66,.5],[.66,.455],[.695,.455],[.7,.485]],count:18000,width:.085}
 ];
 const ribbonPalette=['#6686ac','#a8bdd4','#d8ddcf','#8ca9c8','#3e5d86','#b9cadd'].map(c=>new T.Color(c));
 const uv=new T.Vector3(),uvNext=new T.Vector3(),nextPoint=new T.Vector3();
 for(const ribbon of ribbons){
  const curve=new T.CatmullRomCurve3(ribbon.points.map(([u,v])=>new T.Vector3(u,v,0)),false,'centripetal');
  for(let i=0;i<ribbon.count;i++){
   const t=random(),across=(random()+random()+random()-1.5)/2;curve.getPoint(t,uv);curve.getTangent(t,uvNext);
   const width=ribbon.width*(.6+.4*Math.sin(t*Math.PI));
   const u=uv.x-uvNext.y*across*width,v=uv.y+uvNext.x*across*width;
   const depthOffset=-18-22*Math.cos(across*Math.PI*1.4)+(random()-.5)*32;
   point.copy(paintingPoint(u,v,depthOffset));
   nextPoint.copy(paintingPoint(u+uvNext.x*.001,v+uvNext.y*.001,depthOffset));
   tangent.copy(nextPoint).sub(point).normalize();n.copy(point).sub(center).normalize();
   normalForVolume.copy(n).addScaledVector(tangent,(random()-.5)*.7).normalize();
   const crest=Math.max(0,1-Math.abs(across)*1.5);
   colour.copy(ribbonPalette[Math.floor(random()*ribbonPalette.length)]).multiplyScalar(.72+crest*.24+random()*.12);
   brush.stroke(point,tangent,normalForVolume,1.1+random()*1.8,.22+random()*.25,colour,.68+random()*.25,1);
  }
 }
 // Broad volumetric curls also cover the upper hemisphere and zenith.
 // Their irregular cross sections avoid both flat rings and striped tubes.
 const upperCount=90000,upperCenters=[[-1.1,.88],[-.15,1.18],[.85,.94],[1.9,1.15],[2.9,.9]];
 for(let i=0;i<upperCount;i++){
  const [theta0,el0]=upperCenters[i%upperCenters.length],t=random(),angle=t*Math.PI*3.2;
  const coil=.025+t*.19,across=(random()+random()-1)*.075;
  const theta=theta0+Math.cos(angle)*(coil+across)/Math.max(.35,Math.cos(el0));
  const el=T.MathUtils.clamp(el0+Math.sin(angle)*(coil+across)*.7,.5,1.54);
  const ce=Math.cos(el),se=Math.sin(el),r=205+relief(theta,el)*.6+(random()-.5)*65;
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  tangent.copy(east).multiplyScalar(-Math.sin(angle)).addScaledVector(north,Math.cos(angle)*.7).addScaledVector(n,.25*Math.sin(angle*2)).normalize();
  normalForVolume.copy(n).addScaledVector(north,(random()-.5)*.6).normalize();point.copy(n).multiplyScalar(r).add(center);
  colour.copy(ribbonPalette[Math.floor(random()*ribbonPalette.length)]).multiplyScalar(.8+random()*.22);
  brush.stroke(point,tangent,normalForVolume,1.2+random()*2,.25+random()*.3,colour,.72+random()*.25,1);
 }
 function paintingPoint(u:number,v:number,offset=0){
  const theta=(u-.5)/.88*(Math.PI/2);
  const el=.25*Math.acos(T.MathUtils.clamp(v/.3-1,-1,1));
  field(theta,el);
  const lightPaint=T.MathUtils.smoothstep(a[0]*.2126+a[1]*.7152+a[2]*.0722,.14,.48);
  return new T.Vector3(Math.sin(theta)*Math.cos(el),Math.sin(el),-Math.cos(theta)*Math.cos(el)).multiplyScalar(radius+relief(theta,el)-lightPaint*15+offset).add(center);
 }
 return{paintingPoint,center,radius,strokeCount:perLayer*layers+volumeCount+outerCount+distantCount+upperCount+ribbons.reduce((sum,r)=>sum+r.count,0)};
}
