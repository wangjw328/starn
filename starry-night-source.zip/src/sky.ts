import * as T from 'three';

type Brush={stroke:(p:T.Vector3,t:T.Vector3,n:T.Vector3,length:number,width:number,color:T.Color,opacity?:number,motion?:number)=>void};
const TAU=Math.PI*2;
const wrap=(x:number)=>x-Math.floor(x);

/** One periodic colour/direction field covers the whole hemisphere, including the pole. */
export async function buildSurroundSky(brush:Brush){
 const response=await fetch('./assets/strokes.bin');
 if(!response.ok)throw new Error('原画笔触数据未能加载。');
 const source=new Float32Array(await response.arrayBuffer()),w=192,h=128,channels=5;
 let grid=new Float32Array(w*h*channels),counts=new Uint16Array(w*h);
 for(let j=0;j<source.length;j+=7){
  if(source[j+1]>.64)continue;
  const x=Math.min(w-1,Math.floor(source[j]*w)),y=Math.min(h-1,Math.floor(source[j+1]/.64*h)),cell=y*w+x,k=cell*channels,a=source[j+2]*2;
  grid[k]+=source[j+4];grid[k+1]+=source[j+5];grid[k+2]+=source[j+6];grid[k+3]+=Math.cos(a);grid[k+4]+=Math.sin(a);counts[cell]++;
 }
 for(let i=0;i<counts.length;i++)if(counts[i])for(let c=0;c<channels;c++)grid[i*channels+c]/=counts[i];
 // Fill sparse sampling holes without blurring the populated paint directions.
 for(let pass=0;pass<8;pass++){
  const next=grid.slice(),filled=counts.slice();let empty=0;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
   const i=y*w+x;if(counts[i])continue;let n=0;
   for(const[dx,dy]of[[-1,0],[1,0],[0,-1],[0,1]]){
    const xx=Math.max(0,Math.min(w-1,x+dx)),yy=Math.max(0,Math.min(h-1,y+dy)),j=yy*w+xx;
    if(!counts[j])continue;n++;for(let c=0;c<channels;c++)next[i*channels+c]+=grid[j*channels+c];
   }
   if(n){for(let c=0;c<channels;c++)next[i*channels+c]/=n;filled[i]=1;}else empty++;
  }
  grid=next;counts=filled;if(!empty)break;
 }
 const a=new Float32Array(channels),b=new Float32Array(channels),cap=new Float32Array(channels);
 function sample(u:number,v:number,out:Float32Array){
  // Keep the painting’s right-hand mountain silhouette out of the surrounding sky.
  v-=.14*T.MathUtils.smoothstep(u,.78,.94)*T.MathUtils.smoothstep(v,.45,.6);
  const x=T.MathUtils.clamp(u,0,1)*(w-1),y=T.MathUtils.clamp(v/.64,0,1)*(h-1),ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy;
  out.fill(0);
  for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){
   const k=(Math.min(h-1,iy+dy)*w+Math.min(w-1,ix+dx))*channels,weight=(dx?fx:1-fx)*(dy?fy:1-fy);
   for(let c=0;c<channels;c++)out[c]+=grid[k+c]*weight;
  }
 }
 const center=new T.Vector3(0,12,0),radius=224;
 function field(theta:number,elevation:number){
  // Four overlapping traversals of the original paint field, with matched endpoint values.
  const phase=wrap((theta+.14*Math.sin(theta*4))/(Math.PI/2)+.38/.88),q=phase*.88;
  const v=.6*(.5+.5*Math.cos(elevation*4));
  sample(q+.12,v,a);
  if(q>.76){sample(q-.76,v,b);const blend=T.MathUtils.smoothstep(q,.76,.88);for(let c=0;c<channels;c++)a[c]+=(b[c]-a[c])*blend;}
  // At the zenith, use a continuous planar swirl rather than an azimuth singularity.
  const ce=Math.cos(elevation),twist=theta+ce*6;
  sample(.5+.34*ce*Math.cos(twist),.32+.25*ce*Math.sin(twist),cap);
  const overhead=T.MathUtils.smoothstep(elevation,.95,1.4);
  for(let c=0;c<channels;c++)a[c]+=(cap[c]-a[c])*overhead;
  return overhead;
 }
 let seed=4291889;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const colour=new T.Color(),n=new T.Vector3(),east=new T.Vector3(),north=new T.Vector3(),tangent=new T.Vector3(),point=new T.Vector3();
 // Preserve the original sampled pigments instead of remapping them to a new palette.
 function pigment(){colour.setRGB(a[0]*.74,a[1]*.74,a[2]*.74,T.LinearSRGBColorSpace);}
 const perLayer=245000,layers=3;
 for(let layer=0;layer<layers;layer++)for(let i=0;i<perLayer;i++){
  const theta=(random()-.5)*TAU,elevation=Math.asin(-.085+random()*1.085),ce=Math.cos(elevation),se=Math.sin(elevation);
  const overhead=field(theta,elevation),angle=.5*Math.atan2(a[4],a[3]);
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);
  east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  const eastFlow=Math.cos(angle)*(1-overhead)+overhead,northFlow=-Math.sin(angle)*Math.sin(elevation*4)*(1-overhead)+overhead*.32;
  tangent.copy(east).multiplyScalar(eastFlow).addScaledVector(north,northFlow).normalize();
  const ripples=7*Math.sin(theta*4+elevation*5)*Math.cos(elevation)**2+4*Math.cos(theta*7-elevation*9)*Math.cos(elevation)**2;
  point.copy(n).multiplyScalar(radius+layer*7+ripples+(random()-.5)*2.5).add(center);
  pigment();
  brush.stroke(point,tangent,n,1.05+random()*1.15,.23+random()*.15,colour,1,1);
 }
 // A 140-metre-deep cloud volume sits in front of and through the distant field.
 // Shared angular coordinates preserve the large painting swirls from a distance;
 // radial separation, rolled normals and curled depth create parallax inside them.
 const normalForVolume=new T.Vector3(),volumeCount=340000;
 for(let i=0;i<volumeCount;i++){
  const theta=(random()-.5)*TAU,el=.12+random()*1.38,ce=Math.cos(el),se=Math.sin(el);
  const overhead=field(theta,el),angle=.5*Math.atan2(a[4],a[3]);pigment();
  const depth=random(),r=(i<235000?118+depth*145:265+depth*275)+9*Math.sin(theta*5+el*13+depth*8);
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);
  east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  tangent.copy(east).multiplyScalar(Math.cos(angle)*(1-overhead)+overhead).addScaledVector(north,-Math.sin(angle)*Math.sin(el*4)*(1-overhead)+overhead*.32).addScaledVector(n,.22*Math.sin(el*15+theta*4+depth*8)).normalize();
  point.copy(n).multiplyScalar(r).add(center);
  normalForVolume.copy(n).addScaledVector(north,.5*Math.sin(depth*9+theta*3)).normalize();
  brush.stroke(point,tangent,normalForVolume,(.5+random()*1.1)*r/radius,(.1+random()*.17)*r/radius,colour,.75+random()*.25,1);
 }
 // Distant continuation stays beyond the entire flyable space, so crossing
 // the foreground cloud never reveals a blank background.
 const distantCount=270000;
 for(let i=0;i<distantCount;i++){
  const theta=(random()-.5)*TAU,el=Math.asin(-.12+random()*1.12),ce=Math.cos(el),se=Math.sin(el);
  const overhead=field(theta,el),angle=.5*Math.atan2(a[4],a[3]);pigment();
  n.set(Math.sin(theta)*ce,se,-Math.cos(theta)*ce);east.set(Math.cos(theta),0,Math.sin(theta));north.set(-Math.sin(theta)*se,ce,Math.cos(theta)*se);
  tangent.copy(east).multiplyScalar(Math.cos(angle)*(1-overhead)+overhead).addScaledVector(north,-Math.sin(angle)*Math.sin(el*4)*(1-overhead)+overhead*.32).normalize();
  point.copy(n).multiplyScalar(700+(random()-.5)*28).add(center);
  brush.stroke(point,tangent,n,4+random()*3,1.1+random()*.7,colour,1,1);
 }
 // Landmarks and solid stars now occupy the same enclosing field as the paint.
 function paintingPoint(u:number,v:number,offset=0){
  let theta=(u-.5)/.88*(Math.PI/2);
  for(let i=0;i<7;i++)theta-= (theta+.14*Math.sin(theta*4)-(u-.5)/.88*(Math.PI/2))/(1+.56*Math.cos(theta*4));
  const el=.25*Math.acos(T.MathUtils.clamp(v/.3-1,-1,1));
  return new T.Vector3(Math.sin(theta)*Math.cos(el),Math.sin(el),-Math.cos(theta)*Math.cos(el)).multiplyScalar(radius+offset).add(center);
 }
 return{paintingPoint,center,radius,strokeCount:perLayer*layers+volumeCount+distantCount};
}
