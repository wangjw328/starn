import * as T from 'three';
import {buildWorld,World} from './world';
import {buildTourFireflies} from './fireflies';
const $=<A extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id)as A;
const canvas=$<HTMLCanvasElement>('world'),root=$('experience');
const orientationTip=$('orientation-tip');
$('orientation-dismiss').addEventListener('click',()=>{orientationTip.hidden=true;});
const camera=new T.PerspectiveCamera(47,innerWidth/innerHeight,.08,2700);
const renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;
renderer.shadowMap.enabled=innerWidth>=700;renderer.shadowMap.type=T.PCFSoftShadowMap;
const keys=new Set<string>(),velocity=new T.Vector3(),desired=new T.Vector3(),forward=new T.Vector3(),right=new T.Vector3();
let world:World,yaw=0,pitch=0,targetYaw=0,targetPitch=0,speed=24,dragging=false,lastX=0,lastY=0,clean=false,ready=false;
let tourFireflies:ReturnType<typeof buildTourFireflies>|undefined;
let wheelImpulse=0,frames=0,perfTime=performance.now(),fps=0,adaptiveTime=0,actualRatio=Math.min(devicePixelRatio,1.5);
let lastFrame=performance.now(),lastHud=0,joystickX=0,joystickY=0,joyPointer:number|null=null,lookPointer:number|null=null;
const clockNode=$('clock'),locationNode=$('location');
type TourPoint={time:number;position:T.Vector3;target:T.Vector3;name:string};
let tourState:'idle'|'running'|'paused'='idle',tourTime=0,tourPoints:TourPoint[]=[],tourAngles:T.Vector2[]=[];
let tourLookX=0,tourLookY=0,freeLens=47;
let tourTimes:number[]=[],tourTracks:number[][]=[];
const tourDuration=82;
const tourLengthLabel=`${Math.floor(tourDuration/60)}:${String(tourDuration%60).padStart(2,'0')}`;
// Time-aware Hermite interpolation keeps velocity continuous through every waypoint.
function tourSample(values:number[],segment:number,time:number){
 const i=segment,j=i+1,times=tourTimes,span=times[j]-times[i],u=(time-times[i])/span;
 const slope=(k:number)=>{if(k===values.length-1)return 0;const before=Math.max(0,k-1),after=Math.min(values.length-1,k+1);return(values[after]-values[before])/(times[after]-times[before]);};
 return(2*u*u*u-3*u*u+1)*values[i]+(u*u*u-2*u*u+u)*span*slope(i)+(-2*u*u*u+3*u*u)*values[j]+(u*u*u-u*u)*span*slope(j);
}
const tourPanel=$('tour-panel'),tourProgress=$<HTMLInputElement>('tour-progress');
function tourLensAt(time:number){return 47+11*T.MathUtils.smoothstep(time,41,59)*(1-T.MathUtils.smoothstep(time,65,tourDuration));}
function endTour(){
 const wasTouring=tourState!=='idle';
 if(wasTouring)freeLens=tourLensAt(tourTime);
 tourState='idle';tourPanel.hidden=true;$('tour-start').hidden=false;root.classList.remove('touring');
 canvas.dataset.mode='free';$('explore-mode').textContent='自由探索';stop();
 if(wasTouring)$('description').textContent='已切回自由探索，可从当前位置继续飞行';
}
function startTour(){
 if(!ready)return;setView(0);stop();tourTime=0;tourLookX=tourLookY=0;
 const at=(x:number,z:number,h:number)=>new T.Vector3(x,world.ground(x,z)+h,z);
 const initialTarget=camera.getWorldDirection(new T.Vector3()).multiplyScalar(30).add(camera.position);
 tourPoints=[
  {time:0,position:camera.position.clone(),target:initialTarget,name:'原画视角'},
  {time:14,position:at(14,67,3.6),target:at(-6,48,1.8),name:'麦田'},
  {time:24,position:at(-6,43,4.2),target:at(0,5,5),name:'麦田'},
  {time:34,position:at(18,13,10),target:new T.Vector3(5,5,-12),name:'房屋'},
  {time:41,position:at(30,-15,14),target:new T.Vector3(5,7,-27),name:'教堂'},
  {time:47,position:new T.Vector3(45,22,5),target:new T.Vector3(5,15,-27),name:'后退拉远'},
  {time:53,position:new T.Vector3(45,35,32),target:new T.Vector3(0,30,-55),name:'天地展开'},
  {time:59,position:new T.Vector3(33,44,61),target:new T.Vector3(0,30,-65),name:'村庄上空'},
  {time:65,position:new T.Vector3(18,40,87),target:new T.Vector3(0,30,-80),name:'弧线回望'},
  {time:71,position:new T.Vector3(6,28,100),target:new T.Vector3(0,20,-65),name:'返回原画'},
  {time:77,position:new T.Vector3(1,15,96),target:world.landmarks[0].target.clone(),name:'返回原画'},
  {time:tourDuration,position:world.landmarks[0].position.clone(),target:world.landmarks[0].target.clone(),name:'原画视角'}
 ];
 // Interpolate planned headings directly. A target passing above the camera
 // used to flip yaw by 180 degrees even though the camera path was smooth.
 tourAngles=[];for(const p of tourPoints){
  const dx=p.target.x-p.position.x,dy=p.target.y-p.position.y,dz=p.target.z-p.position.z;
  let heading=Math.atan2(-dx,-dz);
  if(tourAngles.length){const previous=tourAngles[tourAngles.length-1].x;heading=previous+T.MathUtils.euclideanModulo(heading-previous+Math.PI,Math.PI*2)-Math.PI;}
  tourAngles.push(new T.Vector2(heading,Math.atan2(dy,Math.hypot(dx,dz))));
 }
 tourTimes=tourPoints.map(p=>p.time);tourTracks=[tourPoints.map(p=>p.position.x),tourPoints.map(p=>p.position.y),tourPoints.map(p=>p.position.z),tourAngles.map(a=>a.x),tourAngles.map(a=>a.y)];
 tourState='running';tourPanel.hidden=false;$('tour-start').hidden=true;root.classList.add('touring');
 $('explore-mode').textContent='自动漫游';$('tour-pause').textContent='暂停';
 document.querySelectorAll('[data-landmark]').forEach(b=>b.setAttribute('aria-pressed','false'));
}
function pauseTour(){
 if(tourState==='idle')return;tourState=tourState==='running'?'paused':'running';
 $('tour-pause').textContent=tourState==='paused'?'继续':'暂停';canvas.dataset.mode=tourState==='paused'?'tour-paused':'tour';
}
function updateTour(dt:number){
 if(tourState==='running')tourTime=Math.min(tourDuration,tourTime+dt);
 let segment=0;while(segment<tourPoints.length-2&&tourTime>tourPoints[segment+1].time)segment++;
 const a=tourPoints[segment],b=tourPoints[segment+1],local=T.MathUtils.clamp((tourTime-a.time)/(b.time-a.time),0,1);
 camera.position.set(tourSample(tourTracks[0],segment,tourTime),tourSample(tourTracks[1],segment,tourTime),tourSample(tourTracks[2],segment,tourTime));
 camera.position.y=Math.max(camera.position.y,world.ground(camera.position.x,camera.position.z)+2.8);
 if(!dragging){tourLookX=T.MathUtils.damp(tourLookX,0,1.3,dt);tourLookY=T.MathUtils.damp(tourLookY,0,1.3,dt);}

 targetYaw=yaw+T.MathUtils.euclideanModulo(tourSample(tourTracks[3],segment,tourTime)+tourLookX-yaw+Math.PI,Math.PI*2)-Math.PI;
 targetPitch=T.MathUtils.clamp(tourSample(tourTracks[4],segment,tourTime)+tourLookY,-1.2,.65);
 yaw=T.MathUtils.damp(yaw,targetYaw,3.5,dt);pitch=T.MathUtils.damp(pitch,targetPitch,3.5,dt);camera.rotation.set(pitch,yaw,0,'YXZ');
 const stage=local<.45?a.name:b.name;locationNode.textContent=stage;
 $('description').textContent='麦田 → 教堂 → 天地展开 → 弧线回望 → 返回原画';$('tour-stage').textContent=stage;
 tourProgress.value=String(tourTime);$('tour-time').textContent=`${Math.floor(tourTime/60)}:${String(Math.floor(tourTime%60)).padStart(2,'0')} / ${tourLengthLabel}`;
 canvas.dataset.mode=tourState==='paused'?'tour-paused':'tour';canvas.dataset.tourStage=stage;
 if(tourTime===tourDuration){endTour();locationNode.textContent='原画视角';$('description').textContent='已沿弧线回到原画视角，可以继续自由探索';document.querySelector('[data-landmark="0"]')?.setAttribute('aria-pressed','true');}
}
function setView(index:number){
 if(!world)return;endTour();const mark=world.landmarks[index];
 camera.position.copy(mark.position);camera.lookAt(mark.target);
 const e=new T.Euler().setFromQuaternion(camera.quaternion,'YXZ');targetYaw=yaw=e.y;targetPitch=pitch=e.x;
 velocity.set(0,0,0);wheelImpulse=0;locationNode.textContent=mark.name;$('description').textContent=mark.detail;
 document.querySelectorAll<HTMLButtonElement>('[data-landmark]').forEach((b,i)=>b.setAttribute('aria-pressed',String(i===index)));
}
function toggleClean(){clean=!clean;root.classList.toggle('clean',clean);}
function stop(){keys.clear();velocity.set(0,0,0);wheelImpulse=0;joystickX=joystickY=0;dragging=false;}
function pointLook(dx:number,dy:number){if(tourState!=='idle'){tourLookX=T.MathUtils.clamp(tourLookX-dx*.0028,-.8,.8);tourLookY=T.MathUtils.clamp(tourLookY-dy*.0023,-.35,.35);return;}targetYaw-=dx*.0028;targetPitch-=dy*.0023;targetPitch=T.MathUtils.clamp(targetPitch,-1.52,1.52);}
function resize(){camera.aspect=innerWidth/innerHeight;camera.fov=Math.min(76,2*Math.atan(Math.tan(freeLens*Math.PI/360)*Math.max(1,1.55/camera.aspect))*180/Math.PI);camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);}
function animate(now:number){
 const dt=Math.min((now-lastFrame)/1000,.05);lastFrame=now;if(document.hidden)return;
 if(tourState!=='idle')updateTour(dt);else{
 yaw=T.MathUtils.damp(yaw,targetYaw,22,dt);pitch=T.MathUtils.damp(pitch,targetPitch,22,dt);camera.rotation.set(pitch,yaw,0,'YXZ');
 forward.set(0,0,-1).applyQuaternion(camera.quaternion);right.set(1,0,0).applyQuaternion(camera.quaternion);
 const x=(keys.has('d')||keys.has('ArrowRight')?1:0)-(keys.has('a')||keys.has('ArrowLeft')?1:0)+joystickX;
 const z=(keys.has('w')||keys.has('ArrowUp')?1:0)-(keys.has('s')||keys.has('ArrowDown')?1:0)-joystickY;
 const y=(keys.has('e')?1:0)-(keys.has('q')?1:0);
 desired.set(0,0,0).addScaledVector(forward,z).addScaledVector(right,x);desired.y+=y;
 if(desired.lengthSq()>1)desired.normalize();desired.multiplyScalar(speed*(keys.has('Shift')?3:1));
 desired.addScaledVector(forward,wheelImpulse);wheelImpulse=T.MathUtils.damp(wheelImpulse,0,12,dt);
 velocity.lerp(desired,1-Math.exp(-(desired.lengthSq()>.01?20:30)*dt));
 if(velocity.lengthSq()<.0001)velocity.set(0,0,0);
 camera.position.addScaledVector(velocity,dt);
 const floor=world.ground(camera.position.x,camera.position.z)+.9;
 camera.position.y=T.MathUtils.clamp(camera.position.y,floor,900);
 const flightRange=195+T.MathUtils.smoothstep(camera.position.y,20,80)*655;
 camera.position.x=T.MathUtils.clamp(camera.position.x,-flightRange,flightRange);camera.position.z=T.MathUtils.clamp(camera.position.z,-flightRange,flightRange);
 // The sculpted outer banks are reachable while the background remains beyond
 // the flight envelope, including diagonal travel above the village.
 const skyDistance=Math.hypot(camera.position.x,camera.position.y-12,camera.position.z);
 if(skyDistance>1180){const scale=1180/skyDistance;camera.position.x*=scale;camera.position.y=12+(camera.position.y-12)*scale;camera.position.z*=scale;}
 }
 const tourLens=tourState==='idle'?freeLens:tourLensAt(tourTime);
 const lens=Math.min(76,2*Math.atan(Math.tan(tourLens*Math.PI/360)*Math.max(1,1.55/camera.aspect))*180/Math.PI);
 const nextFov=T.MathUtils.damp(camera.fov,lens,2.2,dt);if(Math.abs(nextFov-camera.fov)>.01){camera.fov=nextFov;camera.updateProjectionMatrix();}
 canvas.dataset.region=Math.hypot(camera.position.x,camera.position.y-12,camera.position.z)>125&&camera.position.y>30?'starlight':'landscape';
 world.update(now*.001);tourFireflies?.update(dt,now*.001,camera,tourState!=='idle');canvas.dataset.companions=tourState==='idle'?'0':String(tourFireflies?.count??0);renderer.render(world.scene,camera);frames++;
 if(now-perfTime>1000){fps=Math.round(frames*1000/(now-perfTime));frames=0;perfTime=now;canvas.dataset.fps=String(fps);canvas.dataset.drawCalls=String(renderer.info.render.calls);canvas.dataset.triangles=String(renderer.info.render.triangles);canvas.dataset.strokes=String(world.strokeCount);}
 if(now-lastHud>150){lastHud=now;const p=camera.position;clockNode.textContent=`高度 ${Math.round(p.y)} m`;canvas.dataset.position=p.toArray().map(v=>v.toFixed(3)).join(',');canvas.dataset.yaw=yaw.toFixed(4);canvas.dataset.pitch=pitch.toFixed(4);canvas.dataset.velocity=velocity.length().toFixed(3);}
 if(fps>0&&fps<35){adaptiveTime+=dt;if(adaptiveTime>4&&actualRatio>.85){actualRatio=Math.max(.85,actualRatio-.15);renderer.setPixelRatio(actualRatio);adaptiveTime=0;}}else adaptiveTime=0;
}
async function init(){
 try{
  world=await buildWorld(text=>$('loading-text').textContent=text);
  tourFireflies=buildTourFireflies(world.scene);
  resize();setView(0);ready=true;canvas.dataset.ready='true';canvas.dataset.mode='free';
  $('loading').classList.add('done');$('loading').setAttribute('aria-hidden','true');renderer.setAnimationLoop(animate);$('building-count').textContent=String(world.buildingCount);
 }catch(error){console.error(error);$('error').hidden=false;$('error-message').textContent=error instanceof Error?error.message:'三维空间未能加载，请刷新重试。';$('loading').classList.add('done');}
}
window.addEventListener('resize',resize);
document.addEventListener('visibilitychange',()=>{lastFrame=performance.now();if(document.hidden){stop();if(tourState==='running')pauseTour();}});window.addEventListener('blur',stop);
$('tour-start').addEventListener('click',startTour);$('tour-pause').addEventListener('click',pauseTour);$('tour-exit').addEventListener('click',endTour);
tourProgress.addEventListener('input',()=>{if(tourState==='idle')return;tourTime=Number(tourProgress.value);tourLookX=tourLookY=0;updateTour(0);yaw=targetYaw;pitch=targetPitch;camera.rotation.set(pitch,yaw,0,'YXZ');});
document.querySelectorAll<HTMLButtonElement>('[data-landmark]').forEach(b=>b.addEventListener('click',()=>{if(ready)setView(Number(b.dataset.landmark));}));
$('reset').addEventListener('click',()=>setView(0));$('clean').addEventListener('click',toggleClean);$('restore').addEventListener('click',toggleClean);
$<HTMLInputElement>('speed').addEventListener('input',e=>{speed=Number((e.target as HTMLInputElement).value);$('speed-value').textContent=`${speed} m/s`;});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await root.requestFullscreen();}catch{$('description').textContent='可在独立浏览器中使用全屏。';}});
$('help').addEventListener('click',()=>{$('help-panel').hidden=!$('help-panel').hidden;});$('help-close').addEventListener('click',()=>{$('help-panel').hidden=true;});
canvas.addEventListener('pointerdown',e=>{if(!ready)return;dragging=true;lookPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId);canvas.focus({preventScroll:true});root.classList.add('interacted');});
canvas.addEventListener('pointermove',e=>{if(!dragging||e.pointerId!==lookPointer)return;pointLook(e.clientX-lastX,e.clientY-lastY);lastX=e.clientX;lastY=e.clientY;});
canvas.addEventListener('pointerup',()=>{dragging=false;lookPointer=null;});canvas.addEventListener('pointercancel',()=>{dragging=false;lookPointer=null;});
canvas.addEventListener('wheel',e=>{e.preventDefault();if(tourState!=='idle')endTour();wheelImpulse=T.MathUtils.clamp(wheelImpulse-e.deltaY*.09,-speed*2.5,speed*2.5);root.classList.add('interacted');},{passive:false});
const joystick=$('joystick'),nub=$('joystick-nub');
function joy(e:PointerEvent){const rect=joystick.getBoundingClientRect(),x=(e.clientX-rect.left-rect.width/2)/35,y=(e.clientY-rect.top-rect.height/2)/35;const length=Math.max(1,Math.hypot(x,y));joystickX=x/length;joystickY=y/length;nub.style.transform=`translate(${joystickX*28}px,${joystickY*28}px)`;}
joystick.addEventListener('pointerdown',e=>{if(tourState!=='idle')endTour();joyPointer=e.pointerId;joystick.setPointerCapture(e.pointerId);joy(e);root.classList.add('interacted');});joystick.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)joy(e);});
function releaseJoy(){joyPointer=null;joystickX=joystickY=0;nub.style.transform='translate(0,0)';}
joystick.addEventListener('pointerup',releaseJoy);joystick.addEventListener('pointercancel',releaseJoy);
for(const[id,key]of[['up','e'],['down','q']]){const el=$(id);el.addEventListener('pointerdown',e=>{if(tourState!=='idle')endTour();el.setPointerCapture(e.pointerId);keys.add(key);});el.addEventListener('pointerup',()=>keys.delete(key));el.addEventListener('pointercancel',()=>keys.delete(key));}
window.addEventListener('keydown',e=>{
 if((e.target as HTMLElement).matches('input'))return;
 const k=e.key.length===1?e.key.toLowerCase():e.key;
 if(tourState!=='idle'&&['w','a','s','d','q','e','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(k))endTour();
 if([' ','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(k))e.preventDefault();keys.add(k);
 if(e.repeat)return;root.classList.add('interacted');
 if(k==='r')setView(0);if(k==='h')toggleClean();if(k==='Escape'){$('help-panel').hidden=true;endTour();}
 if(['1','2','3','4','5','6','7'].includes(k))setView(Number(k)-1);
});
window.addEventListener('keyup',e=>keys.delete(e.key.length===1?e.key.toLowerCase():e.key));
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();stop();renderer.setAnimationLoop(null);$('error').hidden=false;$('error-message').textContent='图形渲染中断，请刷新以重新进入空间。';});
init();

