import * as T from 'three';
import {buildWorld,World} from './world';
const $=<A extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id)as A;
const canvas=$<HTMLCanvasElement>('world'),root=$('experience');
const camera=new T.PerspectiveCamera(47,innerWidth/innerHeight,.08,1400);
const renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);
renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;
renderer.shadowMap.enabled=innerWidth>=700;renderer.shadowMap.type=T.PCFSoftShadowMap;
const keys=new Set<string>(),velocity=new T.Vector3(),desired=new T.Vector3(),forward=new T.Vector3(),right=new T.Vector3();
let world:World,yaw=0,pitch=0,targetYaw=0,targetPitch=0,speed=9,dragging=false,lastX=0,lastY=0,clean=false,ready=false;
let wheelImpulse=0,frames=0,perfTime=performance.now(),fps=0,adaptiveTime=0,actualRatio=Math.min(devicePixelRatio,1.5);
let lastFrame=performance.now(),lastHud=0,joystickX=0,joystickY=0,joyPointer:number|null=null,lookPointer:number|null=null;
const clockNode=$('clock'),locationNode=$('location');
function setView(index:number){
 if(!world)return;const mark=world.landmarks[index];
 camera.position.copy(mark.position);camera.lookAt(mark.target);
 const e=new T.Euler().setFromQuaternion(camera.quaternion,'YXZ');targetYaw=yaw=e.y;targetPitch=pitch=e.x;
 velocity.set(0,0,0);wheelImpulse=0;locationNode.textContent=mark.name;$('description').textContent=mark.detail;
 document.querySelectorAll<HTMLButtonElement>('[data-landmark]').forEach((b,i)=>b.setAttribute('aria-pressed',String(i===index)));
}
function toggleClean(){clean=!clean;root.classList.toggle('clean',clean);}
function stop(){keys.clear();velocity.set(0,0,0);wheelImpulse=0;joystickX=joystickY=0;dragging=false;}
function pointLook(dx:number,dy:number){targetYaw-=dx*.0028;targetPitch-=dy*.0023;targetPitch=T.MathUtils.clamp(targetPitch,-1.52,1.52);}
function resize(){camera.aspect=innerWidth/innerHeight;camera.fov=Math.min(76,2*Math.atan(Math.tan(47*Math.PI/360)*Math.max(1,1.55/camera.aspect))*180/Math.PI);camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);}
function animate(now:number){
 const dt=Math.min((now-lastFrame)/1000,.05);lastFrame=now;if(document.hidden)return;
 yaw=T.MathUtils.damp(yaw,targetYaw,22,dt);pitch=T.MathUtils.damp(pitch,targetPitch,22,dt);camera.rotation.set(pitch,yaw,0,'YXZ');
 forward.set(0,0,-1).applyQuaternion(camera.quaternion);right.set(1,0,0).applyQuaternion(camera.quaternion);
 const x=(keys.has('d')||keys.has('ArrowRight')?1:0)-(keys.has('a')||keys.has('ArrowLeft')?1:0)+joystickX;
 const z=(keys.has('w')||keys.has('ArrowUp')?1:0)-(keys.has('s')||keys.has('ArrowDown')?1:0)-joystickY;
 const y=(keys.has('e')?1:0)-(keys.has('q')?1:0);
 desired.set(0,0,0).addScaledVector(forward,z).addScaledVector(right,x);desired.y+=y;
 if(desired.lengthSq()>1)desired.normalize();desired.multiplyScalar(speed*(keys.has('Shift')?3:1));
 desired.addScaledVector(forward,wheelImpulse);wheelImpulse=T.MathUtils.damp(wheelImpulse,0,12,dt);
 velocity.lerp(desired,1-Math.exp(-(desired.lengthSq()>.01?20:30)*dt));
 if(velocity.lengthSq()<.0001)velocity.set(0,0,0);
 camera.position.addScaledVector(velocity,dt);
 const floor=world.ground(camera.position.x,camera.position.z)+.9;
 camera.position.y=T.MathUtils.clamp(camera.position.y,floor,420);
 const flightRange=195+T.MathUtils.smoothstep(camera.position.y,20,80)*225;
 camera.position.x=T.MathUtils.clamp(camera.position.x,-flightRange,flightRange);camera.position.z=T.MathUtils.clamp(camera.position.z,-flightRange,flightRange);
 canvas.dataset.region=Math.hypot(camera.position.x,camera.position.y-12,camera.position.z)>125&&camera.position.y>30?'starlight':'landscape';
 world.update(now*.001);renderer.render(world.scene,camera);frames++;
 if(now-perfTime>1000){fps=Math.round(frames*1000/(now-perfTime));frames=0;perfTime=now;canvas.dataset.fps=String(fps);canvas.dataset.drawCalls=String(renderer.info.render.calls);canvas.dataset.triangles=String(renderer.info.render.triangles);canvas.dataset.strokes=String(world.strokeCount);}
 if(now-lastHud>150){lastHud=now;const p=camera.position;clockNode.textContent=`高度 ${Math.round(p.y)} m`;canvas.dataset.position=p.toArray().map(v=>v.toFixed(3)).join(',');canvas.dataset.yaw=yaw.toFixed(4);canvas.dataset.pitch=pitch.toFixed(4);canvas.dataset.velocity=velocity.length().toFixed(3);}
 if(fps>0&&fps<35){adaptiveTime+=dt;if(adaptiveTime>4&&actualRatio>.85){actualRatio=Math.max(.85,actualRatio-.15);renderer.setPixelRatio(actualRatio);adaptiveTime=0;}}else adaptiveTime=0;
}
async function init(){
 try{
  world=await buildWorld(text=>$('loading-text').textContent=text);
  resize();setView(0);ready=true;canvas.dataset.ready='true';canvas.dataset.mode='free';
  $('loading').classList.add('done');$('loading').setAttribute('aria-hidden','true');renderer.setAnimationLoop(animate);$('building-count').textContent=String(world.buildingCount);
 }catch(error){console.error(error);$('error').hidden=false;$('error-message').textContent=error instanceof Error?error.message:'三维空间未能加载，请刷新重试。';$('loading').classList.add('done');}
}
window.addEventListener('resize',resize);
document.addEventListener('visibilitychange',()=>{lastFrame=performance.now();if(document.hidden)stop();});window.addEventListener('blur',stop);
document.querySelectorAll<HTMLButtonElement>('[data-landmark]').forEach(b=>b.addEventListener('click',()=>{if(ready)setView(Number(b.dataset.landmark));}));
$('reset').addEventListener('click',()=>setView(0));$('clean').addEventListener('click',toggleClean);$('restore').addEventListener('click',toggleClean);
$<HTMLInputElement>('speed').addEventListener('input',e=>{speed=Number((e.target as HTMLInputElement).value);$('speed-value').textContent=`${speed} m/s`;});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await root.requestFullscreen();}catch{$('description').textContent='可在独立浏览器中使用全屏。';}});
$('help').addEventListener('click',()=>{$('help-panel').hidden=!$('help-panel').hidden;});$('help-close').addEventListener('click',()=>{$('help-panel').hidden=true;});
canvas.addEventListener('pointerdown',e=>{if(!ready)return;dragging=true;lookPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId);canvas.focus({preventScroll:true});root.classList.add('interacted');});
canvas.addEventListener('pointermove',e=>{if(!dragging||e.pointerId!==lookPointer)return;pointLook(e.clientX-lastX,e.clientY-lastY);lastX=e.clientX;lastY=e.clientY;});
canvas.addEventListener('pointerup',()=>{dragging=false;lookPointer=null;});canvas.addEventListener('pointercancel',()=>{dragging=false;lookPointer=null;});
canvas.addEventListener('wheel',e=>{e.preventDefault();wheelImpulse=T.MathUtils.clamp(wheelImpulse-e.deltaY*.09,-speed*2.5,speed*2.5);root.classList.add('interacted');},{passive:false});
const joystick=$('joystick'),nub=$('joystick-nub');
function joy(e:PointerEvent){const rect=joystick.getBoundingClientRect(),x=(e.clientX-rect.left-rect.width/2)/35,y=(e.clientY-rect.top-rect.height/2)/35;const length=Math.max(1,Math.hypot(x,y));joystickX=x/length;joystickY=y/length;nub.style.transform=`translate(${joystickX*28}px,${joystickY*28}px)`;}
joystick.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joystick.setPointerCapture(e.pointerId);joy(e);root.classList.add('interacted');});joystick.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)joy(e);});
function releaseJoy(){joyPointer=null;joystickX=joystickY=0;nub.style.transform='translate(0,0)';}
joystick.addEventListener('pointerup',releaseJoy);joystick.addEventListener('pointercancel',releaseJoy);
for(const[id,key]of[['up','e'],['down','q']]){const el=$(id);el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);keys.add(key);});el.addEventListener('pointerup',()=>keys.delete(key));el.addEventListener('pointercancel',()=>keys.delete(key));}
window.addEventListener('keydown',e=>{
 if((e.target as HTMLElement).matches('input'))return;
 const k=e.key.length===1?e.key.toLowerCase():e.key;
 if([' ','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(k))e.preventDefault();keys.add(k);
 if(e.repeat)return;root.classList.add('interacted');
 if(k==='r')setView(0);if(k==='h')toggleClean();if(k==='Escape'){$('help-panel').hidden=true;stop();}
 if(['1','2','3','4','5','6','7'].includes(k))setView(Number(k)-1);
});
window.addEventListener('keyup',e=>keys.delete(e.key.length===1?e.key.toLowerCase():e.key));
canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();stop();renderer.setAnimationLoop(null);$('error').hidden=false;$('error-message').textContent='图形渲染中断，请刷新以重新进入空间。';});
init();
