import * as T from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';
import {buildFields} from './fields';
import {CLOUD_LIGHT_GLSL} from './cloud-light';
import {buildFireflies} from './fireflies';
import {buildSurroundSky} from './sky';
import {buildGroundDetails} from './terrain-details';

export type Landmark={name:string;position:T.Vector3;target:T.Vector3;detail:string};
export type World={scene:T.Scene;landmarks:Landmark[];strokeCount:number;buildingCount:number;ground:(x:number,z:number)=>number;update:(seconds:number)=>void};
const V=(x=0,y=0,z=0)=>new T.Vector3(x,y,z);
const UP=V(0,1,0);
const SKY_CURL_AXES=[V(0,Math.sin(.38),-Math.cos(.38)),V(Math.cos(.38),Math.sin(.38),0),V(0,Math.sin(.38),Math.cos(.38)),V(-Math.cos(.38),Math.sin(.38),0)];
let seed=1889;
const rnd=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const rand=(a:number,b:number)=>a+(b-a)*rnd();
const pick=<A>(a:A[])=>a[Math.floor(rnd()*a.length)];
const blue=['#203d60','#355575','#56758b','#738e97','#a6b7aa','#152e52','#2c4b71'];
const land=['#18323a','#284544','#365856','#576654','#64735c','#142c32'];
const gold=['#b9a654','#dfc267','#efda88','#a9a379','#d1c785'];
const colourCache=new Map<string,T.Color>();
const paintTime={value:0};
const paintMoon={value:V(80,65,-80)};
function col(s:string){let c=colourCache.get(s);if(!c){c=new T.Color(s);colourCache.set(s,c);}return c;}

class Brushwork{
 readonly uniforms={fogColor:{value:new T.Color('#1d354e')},moonPosition:{value:V(80,65,-80)},time:{value:0},curlAngle:{value:0},flowSin:{value:new T.Vector4()},flowCos:{value:new T.Vector4(1,1,1,1)},curlAngles:{value:new T.Vector4()}};
 private attempted=0;
 origins:number[]=[];tangents:number[]=[];normals:number[]=[];sizes:number[]=[];colours:number[]=[];motions:number[]=[];flowPhases:number[]=[];flowRates:number[]=[];
 stroke(p:T.Vector3,t:T.Vector3,n:T.Vector3,length:number,width:number,c:string|T.Color,opacity=1,motion=0){
  if(innerWidth<700&&this.attempted++%2)return;
  this.origins.push(p.x,p.y,p.z);this.tangents.push(t.x,t.y,t.z);this.normals.push(n.x,n.y,n.z);
  if(motion){
   const dx=p.x,dy=p.y-12,dz=p.z,d=Math.hypot(dx,dy,dz),nx=dx/d,ny=dy/d,nz=dz/d;
   // Smoothly blend front, side, rear and overhead vortices. No static gaps
   // between the old narrow curl masks, and no seams at sector boundaries.
   let ax=0,ay=0,az=0,strongest=0;
   for(const axis of SKY_CURL_AXES){
    const weight=Math.exp((nx*axis.x+ny*axis.y+nz*axis.z-1)*12);
    ax+=axis.x*weight;ay+=axis.y*weight;az+=axis.z*weight;strongest=Math.max(strongest,weight);
   }
   const cap=Math.exp((ny-1)*6)*.85;ay+=cap;strongest=Math.max(strongest,cap);
   const axisLength=Math.hypot(ax,ay,az),phase=ny*3+.5*Math.sin(Math.atan2(dx,-dz)*4),scale=d/224;
   this.motions.push(ax/axisLength,ay/axisLength,az/axisLength,.4+.6*strongest);
   this.flowPhases.push(Math.sin(phase)*scale,Math.cos(phase)*scale);
   const speed=(.5+.5*Math.sin(Math.atan2(dx,-dz)*2+ny*4))*3,index=Math.min(2,Math.floor(speed)),blend=T.MathUtils.smoothstep(speed-index,0,1);
   for(let i=0;i<4;i++)this.flowRates.push(i===index?1-blend:i===index+1?blend:0);
  }else{this.motions.push(0,0,0,0);this.flowPhases.push(0,0);this.flowRates.push(0,0,0,0);}
  this.sizes.push(length,width,rnd(),opacity);const color=typeof c==='string'?col(c):c;this.colours.push(color.r,color.g,color.b);
 }
 finish(scene:T.Scene){
  const plane=new T.PlaneGeometry(1,1,2,1),g=new T.InstancedBufferGeometry();g.index=plane.index;
  g.setAttribute('position',plane.attributes.position);g.setAttribute('uv',plane.attributes.uv);
  for(const [name,a,size]of [['aOrigin',this.origins,3],['aTangent',this.tangents,3],['aNormal',this.normals,3],['aSize',this.sizes,4],['aColor',this.colours,3],['aCurl',this.motions,4],['aFlowPhase',this.flowPhases,2],['aFlowRates',this.flowRates,4]]as const){g.setAttribute(name,new T.InstancedBufferAttribute(new Float32Array(a),size));}
  g.instanceCount=this.origins.length/3;
  const m=new T.ShaderMaterial({side:T.DoubleSide,transparent:true,depthWrite:true,uniforms:this.uniforms,vertexShader:`
   attribute vec3 aOrigin,aTangent,aNormal,aColor;attribute vec4 aSize;attribute vec4 aCurl;attribute vec2 aFlowPhase;attribute vec4 aFlowRates;uniform vec4 curlAngles,flowSin,flowCos;
   varying vec2 vUv;varying vec3 vColor,vWorld,vNormal,vTangent;varying float vDistance,vSeed,vOpacity;
   vec3 curlRotate(vec3 v,vec3 axis,float angle){
    // Stable small-angle rotation: no trigonometry per vertex.
    vec3 turn=cross(axis,v);return v+turn*angle+cross(axis,turn)*(angle*angle*.5);
   }
   void main(){
    vec3 origin=aOrigin,tangent=normalize(aTangent),normal=normalize(aNormal);
    float angle=dot(curlAngles,aFlowRates)*aCurl.w;
    origin=vec3(0.,12.,0.)+curlRotate(origin-vec3(0.,12.,0.),aCurl.xyz,angle);
    tangent=curlRotate(tangent,aCurl.xyz,angle);normal=curlRotate(normal,aCurl.xyz,angle);
    origin+=tangent*3.6*(dot(flowSin,aFlowRates)*aFlowPhase.y+dot(flowCos,aFlowRates)*aFlowPhase.x);
    vec3 bitangent=normalize(cross(normal,tangent));
    float ridge=(1.-pow(position.x*2.,2.))*.009;
    vec3 p=origin+tangent*position.x*aSize.x+bitangent*position.y*aSize.y+normal*ridge;
    vec4 mv=modelViewMatrix*vec4(p,1.);
    gl_Position=projectionMatrix*mv;vUv=uv;vColor=aColor;vSeed=aSize.z;vDistance=-mv.z;
    vWorld=p;vNormal=normal;vTangent=tangent;vOpacity=aSize.w;
   }`,fragmentShader:`
   uniform vec3 fogColor,moonPosition;uniform float time;
   ${CLOUD_LIGHT_GLSL}
   varying vec2 vUv;varying vec3 vColor,vWorld,vNormal,vTangent;varying float vDistance,vSeed,vOpacity;
   void main(){
    float along=abs(vUv.x*2.-1.),across=abs(vUv.y*2.-1.);
    float taper=pow(max(0.,1.-along*along),.35);
    if(across>taper)discard;
    float bristle=.88+.12*sin(vUv.y*55.+sin(vUv.x*16.)*.7+vSeed*14.);
    float ridge=1.+.17*exp(-pow((vUv.y-.32)*12.,2.));
    vec3 n=normalize(vNormal),light=normalize(moonPosition-vWorld),eye=normalize(cameraPosition-vWorld);
    vec3 halfVector=normalize(light+eye);
    float diffuse=abs(dot(n,light)),facing=abs(dot(n,eye));
    float sheen=pow(abs(dot(n,halfVector)),22.)*(.45+.55*pow(1.-abs(dot(normalize(vTangent),halfVector)),3.));
    float rim=pow(1.-facing,3.);
    float surface=1.-smoothstep(12.,27.,vWorld.y);
    float cloud=cloudTransmission(vWorld,moonPosition,time);
    vec3 c=vColor*(.86+.21*diffuse)*bristle*ridge*mix(1.,cloud,surface);
    c+=vColor*sheen*mix(.13,.4,surface)+vec3(.025,.04,.065)*rim*.12;
    c+=vec3(.05,.034,.009)*sheen*surface;
    float backlight=pow(max(0.,dot(normalize(vWorld-vec3(0.,12.,0.)),normalize(moonPosition-vec3(0.,12.,0.)))),18.);
    c+=vec3(.045,.034,.013)*backlight*(1.-surface)*cloud;
    float fog=(1.-exp(-vDistance*vDistance*.000007))*surface;
    vec3 mist=fogColor+vec3(.034,.025,.008)*pow(max(0.,dot(-eye,light)),8.);
    c=mix(c,mist,fog);
    float proximity=mix(smoothstep(3.,12.,vDistance),smoothstep(.12,.7,vDistance),surface);
    float alpha=smoothstep(taper,taper-.18,across)*proximity*vOpacity*mix(.78+.22*cloud,1.,surface);
    if(alpha<.12)discard;
    gl_FragColor=vec4(c,alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
   }`});
  const mesh=new T.Mesh(g,m);mesh.frustumCulled=false;mesh.renderOrder=2;scene.add(mesh);
  return g.instanceCount;
 }
}
function paintedMaterial(c:string,roughness=.72){
 const m=new T.MeshStandardMaterial({color:c,roughness,metalness:.02});
 m.onBeforeCompile=shader=>{
  shader.uniforms.paintTime=paintTime;shader.uniforms.paintMoon=paintMoon;
  shader.vertexShader='varying vec3 vPaintPosition;varying vec3 vPaintNormal;\n'+shader.vertexShader;
  shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
vec4 paintWorld=vec4(transformed,1.);
#ifdef USE_INSTANCING
paintWorld=instanceMatrix*paintWorld;
#endif
vPaintPosition=(modelMatrix*paintWorld).xyz;vPaintNormal=mat3(modelMatrix)*normal;`);
  shader.fragmentShader='uniform float paintTime;uniform vec3 paintMoon;varying vec3 vPaintPosition;varying vec3 vPaintNormal;\n'+CLOUD_LIGHT_GLSL+shader.fragmentShader;
  shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
   vec3 an=abs(normalize(vPaintNormal));
   vec2 pp=an.y>an.x&&an.y>an.z?vPaintPosition.xz:(an.x>an.z?vPaintPosition.zy:vPaintPosition.xy);
   pp.x+=.06*sin(pp.y*3.7);
   vec2 cell=floor(pp*vec2(3.,12.));
   float broken=fract(sin(dot(cell,vec2(127.1,311.7)))*43758.5453);
   float bristles=sin(pp.y*137.+sin(pp.x*8.)*2.);
   float pigment=.74+.32*broken+.09*bristles;
   float cloudShade=cloudTransmission(vPaintPosition,paintMoon,paintTime);
   diffuseColor.rgb*=pigment*cloudShade;
  `);
 };
 return m;
}
function mesh(scene:T.Scene,geometry:T.BufferGeometry,material:T.Material,pos:T.Vector3,rotation=0){const m=new T.Mesh(geometry,material);m.position.copy(pos);m.rotation.y=rotation;m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;}

export async function buildWorld(onProgress:(text:string)=>void):Promise<World>{
 seed=1889;
 const scene=new T.Scene();scene.background=new T.Color('#1d354e');scene.fog=new T.FogExp2('#1d354e',.0034);
 scene.add(new T.HemisphereLight('#9fb5d6','#283d3e',1.12));
 scene.add(new T.AmbientLight('#6683b1',.2));
 const moonLight=new T.DirectionalLight('#ffdb9a',1.8);moonLight.position.set(80,65,-80);
 moonLight.castShadow=innerWidth>=700;moonLight.shadow.mapSize.set(2048,2048);moonLight.shadow.camera.left=-110;moonLight.shadow.camera.right=110;moonLight.shadow.camera.top=110;moonLight.shadow.camera.bottom=-110;moonLight.shadow.camera.near=1;moonLight.shadow.camera.far=330;moonLight.shadow.bias=-.00025;moonLight.shadow.normalBias=.06;scene.add(moonLight,moonLight.target);
 const fill=new T.DirectionalLight('#416ab8',.6);fill.position.set(-90,35,110);scene.add(fill);
 for(const[x,z]of[[-12,9],[16,3],[5,-27]]){const lamp=new T.PointLight('#efc476',18,14,1.6);lamp.position.set(x,2.5,z);scene.add(lamp);}
 const brush=new Brushwork();
 const ground=(x:number,z:number)=>{
  const terrain=-2+1.2*Math.sin(x*.07+z*.035)+.8*Math.cos(z*.09-x*.03)+Math.max(0,-z-38)*.045+Math.min(1,Math.max(0,(Math.hypot(x,z+5)-36)/75))*3.1*Math.sin(x*.035+z*.048);
  const fieldEdge=Math.hypot(x/35,(z-47)/23);
  const rolling=-1.65+.65*Math.sin(x*.105+z*.042)+.4*Math.cos(z*.15-x*.045);
  return T.MathUtils.lerp(rolling,terrain,T.MathUtils.smoothstep(fieldEdge,.75,1.25));
 };
 onProgress('塑造山丘与田野');
 await new Promise(r=>setTimeout(r,0));
 const groundSegments=innerWidth<700?240:420;
 const groundGeo=new T.PlaneGeometry(420,420,groundSegments,groundSegments);groundGeo.rotateX(-Math.PI/2);
 const pos=groundGeo.attributes.position;
 for(let i=0;i<pos.count;i++){const x=pos.getX(i),z=pos.getZ(i)-10;pos.setXYZ(i,x,ground(x,z),z);}
 groundGeo.computeVertexNormals();mesh(scene,groundGeo,paintedMaterial('#344c4c'),V());
 // Surface strokes have terrain normals; they stay on the land from every viewpoint.
 for(let i=0;i<62000;i++){
  const x=rand(-195,195),z=rand(-190,185),y=ground(x,z);
  const sx=(ground(x+.1,z)-ground(x-.1,z))/.2,sz=(ground(x,z+.1)-ground(x,z-.1))/.2;
  const n=V(-sx,1,-sz).normalize(),a=.35*Math.sin(x*.08+z*.05);
  const tangent=V(Math.cos(a),sx*Math.cos(a)+sz*Math.sin(a),Math.sin(a)).normalize();
  brush.stroke(V(x,y+.025,z),tangent,n,rand(.35,1.4),rand(.07,.22),pick(land));
 }
 // Painted roads form a connected network through the village.
 function road(points:T.Vector3[],width:number){
  const curve=new T.CatmullRomCurve3(points),p=V(),t=V();
  for(let i=0;i<3000;i++){const u=rnd();curve.getPoint(u,p);curve.getTangent(u,t);const off=rand(-width,width);p.x+=t.z*off;p.z-=t.x*off;p.y=ground(p.x,p.z)+.035;brush.stroke(p,t,UP,rand(.16,.5),rand(.03,.09),pick(['#666b59','#8b8b70','#454f4b','#a09c77']));}
 }
 road([V(-2,0,60),V(3,0,9),V(0,0,-12),V(3,0,-33),V(23,0,-59)],1.2);
 road([V(-32,0,-23),V(-7,0,-20),V(0,0,-12),V(30,0,-7),V(58,0,-22)],.7);
 // Broad sculpted ridges have a front, summit and rear slope.
 for(let k=0;k<3;k++){
  const z=-70-k*25,span=26;
  const summit=(x:number)=>11+4*Math.sin(x*.038+k*.6)+2*Math.sin(x*.105+k)+Math.exp(-(((x-42)/29)**2))*9;
  const height=(x:number,zz:number)=>ground(x,zz)+summit(x)*Math.pow(Math.max(0,Math.cos((zz-z)/span*Math.PI/2)),1.5);
  const mountain=new T.PlaneGeometry(270,span*2,180,52);mountain.rotateX(-Math.PI/2);
  const mp=mountain.attributes.position;
  for(let i=0;i<mp.count;i++){const x=mp.getX(i),zz=mp.getZ(i)+z;mp.setXYZ(i,x,height(x,zz),zz);}
  mountain.computeVertexNormals();mesh(scene,mountain,paintedMaterial(['#264f68','#365a7c','#49688b'][k]),V());
  for(let i=0;i<18000;i++){
   const x=rand(-135,135),zz=z+rand(-span,span),y=height(x,zz);
   const dx=(height(x+.1,zz)-height(x-.1,zz))/.2,dz=(height(x,zz+.1)-height(x,zz-.1))/.2;
   const n=V(-dx,1,-dz).normalize();
   brush.stroke(V(x,y+.04,zz),V(1,dx,0).normalize(),n,rand(.4,1.6),rand(.06,.18),pick(blue));
  }
 }
 onProgress('绘制村庄、门窗与教堂');await new Promise(r=>setTimeout(r,0));
 const wallMats=['#344748','#53605b','#526469','#616a60','#7c7965'].map(c=>paintedMaterial(c));
 const roofMats=['#293e52','#415265','#52605c','#526d68'].map(c=>paintedMaterial(c));
 const windowMat=new T.MeshBasicMaterial({color:'#e6b96b'}),windowDark=paintedMaterial('#0b202c'),doorMat=paintedMaterial('#182b31');
 function building(x:number,z:number,w:number,d:number,h:number,angle:number,church=false){
  const base=ground(x,z),group=new T.Group();group.position.set(x,base,z);group.rotation.y=angle;scene.add(group);
  const wallMaterial=pick(wallMats),roofMaterial=pick(roofMats);
  const wall=new T.Mesh(new T.BoxGeometry(w,h,d),wallMaterial);wall.position.y=h/2;group.add(wall);
  const roofHeight=w*.55;
  const roofGeo=new T.BufferGeometry();
  const verts=[-w/2-.12,h,d/2+.15,w/2+.12,h,d/2+.15,0,h+roofHeight,d/2+.15,-w/2-.12,h,-d/2-.15,0,h+roofHeight,-d/2-.15,w/2+.12,h,-d/2-.15];
  roofGeo.setAttribute('position',new T.Float32BufferAttribute(verts,3));roofGeo.setIndex([0,1,2,3,4,5,0,2,4,0,4,3,1,5,4,1,4,2]);roofGeo.computeVertexNormals();group.add(new T.Mesh(roofGeo,roofMaterial));
  const eave=new T.Mesh(new T.BoxGeometry(w+.25,.09,d+.3),roofMats[0]);eave.position.y=h;group.add(eave);
  if(z>7&&rnd()<.45){const light=new T.PointLight('#efad58',3,5,2);light.position.set(0,.8,d/2+.4);group.add(light);}
  const transform=(p:T.Vector3)=>group.localToWorld(p);
  const rotate=(v:T.Vector3)=>v.applyAxisAngle(UP,angle);
  for(let face=0;face<4;face++){
   const normal=rotate([V(0,0,1),V(1,0,0),V(0,0,-1),V(-1,0,0)][face]);
   const faceW=face%2?d:w;
   for(let i=0;i<Math.round(faceW*h*24);i++){
    const u=rand(-faceW/2,faceW/2),v=rand(.1,h-.05),p=face===0?V(u,v,d/2+.015):face===1?V(w/2+.015,v,u):face===2?V(u,v,-d/2-.015):V(-w/2-.015,v,u);
    brush.stroke(transform(p),rotate(V(face%2?0:1,.12,face%2?1:0).normalize()),normal,rand(.25,.65),rand(.025,.055),wallMaterial.color.clone().multiplyScalar(rand(.6,1.05)));
   }
   const cols=Math.max(1,Math.floor(faceW/.85)),rows=h>2.5?2:1;
   for(let row=0;row<rows;row++)for(let j=0;j<cols;j++){
    const u=-faceW/2+faceW*(j+.5)/cols,yy=.7+row*(h-.8)/rows;
    const pane=new T.Mesh(new T.BoxGeometry(.25,.36,.025),rnd()<.65?windowMat:windowDark);
    pane.position.set(face%2?(face===1?w/2+.025:-w/2-.025):u,yy,face%2?u:(face===0?d/2+.025:-d/2-.025));pane.rotation.y=face*Math.PI/2;group.add(pane);
    for(const sign of[-1,1]){const frame=new T.Mesh(new T.BoxGeometry(.035,.42,.035),doorMat);frame.position.copy(pane.position);if(face%2)frame.position.z+=sign*.15;else frame.position.x+=sign*.15;group.add(frame);}
   }
  }
  for(let slope=0;slope<2;slope++)for(let i=0;i<Math.round(w*d*28);i++){
   const xx=rnd()*w/2*(slope?1:-1),zz=rand(-d/2,d/2),yy=h+roofHeight*(1-Math.abs(xx)/(w/2));
   brush.stroke(transform(V(xx,yy+.03,zz)),rotate(V(0,0,1)),rotate(V(slope?roofHeight:-roofHeight,w/2,0).normalize()),rand(.25,.8),rand(.035,.075),roofMaterial.color.clone().multiplyScalar(rand(.6,1.15)));
  }
  const door=new T.Mesh(new T.BoxGeometry(.4,.8,.04),doorMat);door.position.set(0,.4,d/2+.025);group.add(door);
  if(!church&&rnd()<.55){const chimney=new T.Mesh(new T.BoxGeometry(.25,.65,.25),wallMats[0]);chimney.position.set(w*.2,h+roofHeight*.8,.1);group.add(chimney);}
  return group;
 }
 let buildings=0;
 for(let row=0;row<8;row++)for(let c=0;c<11;c++){
  const x=(c-5)*4.1+rand(-.85,.85),z=-row*5.2+16+rand(-.9,.9);
  if(Math.abs(x)<3.1||Math.abs(x-5)<4&&z<-22&&z>-39)continue;
  building(x,z,rand(1.8,3.2),rand(2.4,4),rand(1.8,3.6),rand(-.32,.32));buildings++;
 }
 // Small outlying homes widen the village rather than packing the central street.
 const outlyingHomes:number[][]=[];
 for(const side of[-1,1])for(let row=0;row<3;row++)for(let col=0;col<3;col++){
  outlyingHomes.push([side*(29+col*8.2+row%2*1.2),-5-row*10.2-col*1.6]);
 }
 for(const x of[-26,-17,-8,15,24,33])outlyingHomes.push([x,-44+Math.sin(x*.3)*1.1]);
 for(const[x,z]of outlyingHomes){
  building(x+rand(-.45,.45),z+rand(-.5,.5),rand(1.8,2.65),rand(2.6,3.5),rand(1.9,2.75),rand(-.42,.42));buildings++;
 }
 // Short branching paths leave broad gardens and clear gaps between the new roofs.
 for(const side of[-1,1])for(let row=0;row<3;row++)for(let i=0;i<115;i++){
  const x=side*(22+i*.23),z=-2-row*10.2-(Math.abs(x)-22)*.18;
  brush.stroke(V(x,ground(x,z)+.045,z),V(1,0,-side*.18).normalize(),UP,rand(.45,.8),rand(.12,.22),pick(['#797859','#55645b','#8e8660']));
 }
 building(5,-31,4.7,8.5,4.9,0,true);buildings++;
 const base=ground(5,-27),tower=mesh(scene,new T.BoxGeometry(1.75,9,1.8),wallMats[2],V(5,base+4.5,-27));
 mesh(scene,new T.ConeGeometry(1.38,9,4),roofMats[0],V(5,base+13.5,-27),Math.PI/4);
 const bellMat=paintedMaterial('#0d2431');
 for(const dir of[-1,1]){mesh(scene,new T.BoxGeometry(.5,.9,.04),bellMat,V(5+dir*.35,base+7.5,-26.075));mesh(scene,new T.BoxGeometry(.04,.9,.5),bellMat,V(5+dir*.9,base+7.5,-27));}
 mesh(scene,new T.BoxGeometry(.07,1,.07),windowMat,V(5,base+18.3,-27));mesh(scene,new T.BoxGeometry(.55,.06,.07),windowMat,V(5,base+18.55,-27));
 for(let i=0;i<1500;i++){const side=Math.floor(rnd()*4),t=rnd(),p=V(5+(side%2?((side===1?1:-1)*.89):rand(-.85,.85)),base+rand(.1,8.9),-27+(side%2?rand(-.85,.85):(side===0?.91:-.91)));brush.stroke(p,V(0,1,0),V(side===1?1:side===3?-1:0,0,side===0?1:side===2?-1:0),rand(.2,.6),.035,pick(['#536c72','#294552','#86968b']));}
 onProgress('塑造柏树的枝簇与笔触');await new Promise(r=>setTimeout(r,0));
 const treeMat=paintedMaterial('#233b38');
 function cypress(x:number,z:number,height:number){
  const y=ground(x,z),group=new T.Group();scene.add(group);
  const trunk=mesh(scene,new T.CylinderGeometry(.15,.5,height*.75,9),paintedMaterial('#1b302b'),V(x,y+height*.375,z));
  for(let k=0;k<9;k++){
   const h=height*rand(.45,1),ox=(k===0?0:rand(-1.9,1.9))*height/32,oz=rand(-.7,.7),width=height*rand(.035,.065);
   const p=V(x+ox,y+h*.45,z+oz),geo=new T.SphereGeometry(1,12,18);
   const vertices=geo.attributes.position;
   for(let i=0;i<vertices.count;i++){const yy=vertices.getY(i),t=(yy+1)/2;const taper=.45+.55*Math.sin(Math.PI*t);vertices.setXYZ(i,vertices.getX(i)*width*taper+.35*Math.sin(t*8+k),yy*h*.5,vertices.getZ(i)*width*.5*taper);}
   geo.computeVertexNormals();mesh(scene,geo,treeMat,p);
   for(let i=0;i<(height>15?3200:240);i++){
    const t=rnd(),a=rnd()*Math.PI*2,taper=.45+.55*Math.sin(Math.PI*t),r=Math.sqrt(Math.max(0,1-(t*2-1)**2));
    const point=V(p.x+Math.cos(a)*width*taper*r+.35*Math.sin(t*8+k),p.y+(t*2-1)*h*.5,p.z+Math.sin(a)*width*.5*taper*r);
    brush.stroke(point,V(.2*Math.cos(a),1,.1*Math.sin(a)).normalize(),V(Math.cos(a),.05,Math.sin(a)).normalize(),rand(.35,1.1),rand(.04,.11),pick(['#29483e','#415749','#596452','#263d39','#5d7058','#3a4134']));
   }
  }
 }
 cypress(-21,13,36);cypress(-23,11,25);cypress(-19,10,22);
 for(let i=0;i<8;i++)cypress(rand(-60,60),rand(-65,-48),rand(4,8));
 onProgress('种植麦田，延展侧面和身后的风景');await new Promise(r=>setTimeout(r,0));
 const fields=buildFields(scene,ground);
 for(const[cx,cz]of[[-72,52],[88,45],[-50,135],[65,125]])for(let i=0;i<4;i++)cypress(cx+rand(-11,11),cz+rand(-11,11),rand(6,12));
 for(const[cx,cz]of[[-67,78],[91,-14]])for(let i=0;i<6;i++){
  building(cx+(i%3-1)*4.5,cz+Math.floor(i/3)*5,rand(2,3),rand(2.8,4),rand(2,3.4),rand(-.5,.5));buildings++;
 }
 for(const sector of[-Math.PI/2,Math.PI/2,Math.PI]){
  const ridgePoint=(a:number,v:number)=>{const r=133+v*66,x=Math.sin(a)*r,z=Math.cos(a)*r;return V(x,ground(x,z)+Math.sin(v*Math.PI)*(13+5*Math.sin(a*4)+3*Math.cos(a*7)),z);};
  const ridge=new T.PlaneGeometry(1,1,110,28),p=ridge.attributes.position;
  for(let i=0;i<p.count;i++){
   const a=sector+p.getX(i)*2.05,v=p.getY(i)+.5,r=133+v*66;
   const x=Math.sin(a)*r,z=Math.cos(a)*r,h=Math.sin(v*Math.PI)*(13+5*Math.sin(a*4)+3*Math.cos(a*7));
   p.setXYZ(i,x,ground(x,z)+h,z);
  }
  const indices=ridge.index!;for(let i=0;i<indices.count;i+=3){const b=indices.getX(i+1);indices.setX(i+1,indices.getX(i+2));indices.setX(i+2,b);}
  ridge.computeVertexNormals();mesh(scene,ridge,paintedMaterial('#3e6180'),V());
  for(let i=0;i<14000;i++){
   const a=sector+rand(-1.025,1.025),v=rnd(),point=ridgePoint(a,v);
   const tangent=ridgePoint(a+.001,v).sub(ridgePoint(a-.001,v)).normalize();
   const radial=ridgePoint(a,v+.001).sub(ridgePoint(a,v-.001)).normalize();
   const n=new T.Vector3().crossVectors(radial,tangent).normalize();point.addScaledVector(n,.12);
   brush.stroke(point,tangent,n,rand(.5,1.6),rand(.08,.2),pick(blue));
  }
 }
 // A quiet rear landmark gives exploration a different silhouette.
 const millPosition=V(-43,ground(-43,109),109),millMat=paintedMaterial('#727a6a');
 mesh(scene,new T.CylinderGeometry(.65,1.25,6,10),millMat,millPosition.clone().add(V(0,3,0)));
 mesh(scene,new T.ConeGeometry(1.3,2,10),roofMats[1],millPosition.clone().add(V(0,7,0)));
 const rotor=new T.Group();rotor.position.copy(millPosition).add(V(0,5.7,1.1));scene.add(rotor);
 for(let i=0;i<4;i++){
  const blade=new T.Mesh(new T.BoxGeometry(.38,3.2,.12),millMat);blade.position.set(Math.sin(i*Math.PI/2)*1.6,Math.cos(i*Math.PI/2)*1.6,0);blade.rotation.z=-i*Math.PI/2;blade.userData.dynamic=true;blade.castShadow=true;rotor.add(blade);
 }
 buildGroundDetails(scene,ground,brush,paintedMaterial);
 onProgress('编织连续环绕的星空与头顶旋涡');await new Promise(r=>setTimeout(r,0));
 // A painted sky surrounds the whole world. Its marks follow a sphere-tangent field.
 const skyGeo=new T.SphereGeometry(950,64,40);
 const skyMat=new T.ShaderMaterial({side:T.BackSide,depthWrite:false,vertexShader:`varying vec3 vDir;void main(){vDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`
  varying vec3 vDir;
  float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
  void main(){vec3 d=normalize(vDir);float a=atan(d.x,-d.z),h=asin(d.y);
   vec2 uv=vec2(a*4.,h*7.);float f=sin(uv.x+sin(uv.y*1.8))*cos(uv.y*.8);
   vec2 q=vec2(uv.x*140.,(uv.y+.3*sin(uv.x))*115.);float grain=hash(floor(q));
   float mark=smoothstep(.8,.1,abs(fract(q.y)-.5))*step(.32,grain);
   vec3 c=mix(vec3(.018,.042,.082),vec3(.055,.11,.18),.5+.5*f);
   c+=mark*vec3(.002,.004,.006);
   gl_FragColor=vec4(c,1.);#include <tonemapping_fragment>
   #include <colorspace_fragment>
  }`});
 // Shader includes must begin on their own line.
 skyMat.fragmentShader=skyMat.fragmentShader.replace(';#include',';\n#include');scene.add(new T.Mesh(skyGeo,skyMat));
 const {paintingPoint}=await buildSurroundSky(brush);
 const starMat=paintedMaterial('#dfc57b');starMat.emissive=new T.Color('#b28d45');starMat.emissiveIntensity=.6;starMat.fog=false;
 const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=128;
 const ctx=glowCanvas.getContext('2d')!;const gradient=ctx.createRadialGradient(64,64,0,64,64,64);gradient.addColorStop(0,'rgba(255,207,97,.65)');gradient.addColorStop(.18,'rgba(235,170,69,.27)');gradient.addColorStop(.5,'rgba(211,156,65,.065)');gradient.addColorStop(1,'rgba(213,176,92,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,128,128);
 const glowTexture=new T.CanvasTexture(glowCanvas);glowTexture.colorSpace=T.SRGBColorSpace;
 const glowMaterial=new T.SpriteMaterial({map:glowTexture,fog:false,transparent:true,depthWrite:false,depthTest:false,blending:T.AdditiveBlending,opacity:.24});
 function star(x:number,y:number,z:number,r:number,moon=false){
  const glow=new T.Sprite(glowMaterial);glow.renderOrder=4;glow.position.set(x,y,z);glow.scale.setScalar(r*(moon?6:9));scene.add(glow);
  if(!moon){
   mesh(scene,new T.SphereGeometry(r,24,18),starMat,V(x,y,z));
   for(let i=0;i<1500;i++){
    const zz=rand(-1,1),a=rnd()*Math.PI*2,rr=Math.sqrt(1-zz*zz),normal=V(Math.cos(a)*rr,Math.sin(a)*rr,zz),p=normal.clone().multiplyScalar(r+.025).add(V(x,y,z));
    brush.stroke(p,V(-Math.sin(a),Math.cos(a),.12).normalize(),normal,rand(.1,.28),rand(.025,.07),pick(gold));
   }
  }
  const ringCount=moon?18:10;
  for(let layer=0;layer<ringCount;layer++){
   const radius=r*(1.25+layer*.2),tilt=rand(-.22,.22),depth=rand(-.45,.45);
   for(let i=0;i<160;i++){
    const a=rnd()*Math.PI*2,rr=radius+rand(-.08,.08);
    const p=V(x+Math.cos(a)*rr,y+Math.sin(a)*rr*.9,z+depth+Math.sin(a)*rr*tilt);
    brush.stroke(p,V(-Math.sin(a),Math.cos(a)*.9,Math.cos(a)*tilt).normalize(),V(0,-tilt,1).normalize(),rand(.12,.3),rand(.018,.045),pick(layer>ringCount*.6?['#4779a4','#8aa6bc','#345c88']:gold));
   }
  }
 }
 const starUV=[[.11,.045,1.2],[.232,.035,.7],[.345,.04,1.1],[.414,.069,.8],[.612,.091,1.3],[.235,.171,1.2],[.706,.232,.8],[.327,.324,.6],[.045,.45,.7],[.135,.475,.7],[.36,.52,1.4]];
 for(const[u,v,r]of starUV){const p=paintingPoint(u,v,-60);star(p.x,p.y,p.z,r*1.7);}
 // Crescent is an extruded closed contour, with a painted front, back and rim.
 const moonPos=paintingPoint(.92,.16,-55),R=7.2;
 moonLight.position.copy(moonPos);paintMoon.value.copy(moonPos);brush.uniforms.moonPosition.value.copy(moonPos);
 const shape=new T.Shape();
 shape.moveTo(0,R);shape.bezierCurveTo(-R*1.2,R*.7,-R*1.2,-R*.7,0,-R);shape.bezierCurveTo(-R*.55,-R*.35,-R*.55,R*.35,0,R);
 const crescent=new T.ExtrudeGeometry(shape,{depth:.85,bevelEnabled:true,bevelSize:.13,bevelThickness:.13,bevelSegments:3,curveSegments:32});
 const moonMat=paintedMaterial('#cdbb78');moonMat.emissive=new T.Color('#9f8239');moonMat.emissiveIntensity=.4;moonMat.fog=false;
 mesh(scene,crescent,moonMat,moonPos);
 for(let i=0;i<4000;i++){
  const x=rand(-R,0),y=rand(-R,R);
  // Keep paint marks inside the crescent's broad outer band.
  const outer=(x+.13*R)**2/(.83*R)**2+y*y/(R*R),inner=(x-.33*R)**2/(.83*R)**2+y*y/(.84*R)**2;
  if(outer>1||inner<1)continue;
  const face=rnd()<.5?-.14:.99;
  brush.stroke(moonPos.clone().add(V(x,y,face)),V(-y,x+R*.2,.04).normalize(),V(0,0,face>0?1:-1),rand(.12,.4),rand(.035,.085),pick(gold));
 }
 star(moonPos.x-1,moonPos.y,moonPos.z,R*.8,true);
 // Stars behind and beside the viewer make this an actual surroundable sky.
 for(let i=0;i<12;i++){const a=rand(.2,Math.PI*1.8),radius=rand(85,145);star(Math.sin(a)*radius,rand(25,75),Math.cos(a)*radius,rand(.45,.85));}
 onProgress('整理近处的颜料与细节');await new Promise(r=>setTimeout(r,0));
 scene.updateMatrixWorld(true);
 const batches=new Map<T.Material,T.BufferGeometry[]>(),originals:T.Mesh[]=[];
 scene.traverse(object=>{
  if(!(object instanceof T.Mesh)||object.userData.dynamic||object.material instanceof T.ShaderMaterial||Array.isArray(object.material))return;
  let geometry=object.geometry.clone().applyMatrix4(object.matrixWorld);
  if(geometry.index)geometry=geometry.toNonIndexed();
  if(!geometry.attributes.uv)geometry.setAttribute('uv',new T.Float32BufferAttribute(new Float32Array(geometry.attributes.position.count*2),2));
  const list=batches.get(object.material)||[];list.push(geometry);batches.set(object.material,list);originals.push(object);
 });
 for(const original of originals)original.removeFromParent();
 for(const[material,geometries]of batches){const merged=mergeGeometries(geometries,false);if(merged)mesh(scene,merged,material,V());else for(const geometry of geometries)mesh(scene,geometry,material,V());}
 const fireflies=buildFireflies(scene,ground);
 const count=brush.finish(scene),animationStart=performance.now()*.001;
 const landmarks:Landmark[]=[
  {name:'原画视角',position:V(0,10,87),target:V(0,23,-45),detail:'柏树、村庄与流动的星空'},
  {name:'村庄',position:V(1,2.3,2),target:V(5,5,-27),detail:'穿过街道，靠近屋檐与窗光'},
  {name:'柏树',position:V(-13,12,23),target:V(-21,18,12),detail:'从枝簇之间仰望夜空'},
  {name:'旋涡',position:paintingPoint(.48,.32,-75),target:paintingPoint(.48,.32),detail:'进入星云内部，前后左右都有真实笔触，可继续飞行穿过星光层'},
  {name:'月亮',position:moonPos.clone().add(V(-2,0,15)),target:moonPos.clone(),detail:'观察弯月的厚度与层叠星环'}
 ];
 landmarks.push({name:'麦田',position:V(7,ground(7,66)+2.1,66),target:V(-6,ground(-6,38)+1.2,38),detail:'高低错落的麦田、间歇掠过的麦浪与萤火虫'},{name:'后山',position:V(-20,ground(-20,92)+5,92),target:V(-43,5,109),detail:'风车、池塘、树丛与另一侧的星空'});
 return{scene,landmarks,strokeCount:count,buildingCount:buildings,ground,update:seconds=>{const elapsed=Math.max(0,seconds-animationStart);paintTime.value=elapsed;brush.uniforms.time.value=elapsed;brush.uniforms.curlAngles.value.set(.11*Math.sin(elapsed*.045),.11*Math.sin(elapsed*.075),.11*Math.sin(elapsed*.12),.11*Math.sin(elapsed*.18));brush.uniforms.flowSin.value.set(Math.sin(elapsed*.07),Math.sin(elapsed*.12),Math.sin(elapsed*.19),Math.sin(elapsed*.26));brush.uniforms.flowCos.value.set(Math.cos(elapsed*.07),Math.cos(elapsed*.12),Math.cos(elapsed*.19),Math.cos(elapsed*.26));fireflies.update(elapsed);fields.update(elapsed,moonPos);rotor.rotation.z=-elapsed*.13;}};
}
