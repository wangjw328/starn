import * as T from 'three';

type Brush={stroke:(p:T.Vector3,t:T.Vector3,n:T.Vector3,length:number,width:number,c:string|T.Color,opacity?:number)=>void};
export function buildGroundDetails(scene:T.Scene,ground:(x:number,z:number)=>number,brush:Brush,paint:(c:string)=>T.MeshStandardMaterial){
 let seed=188911;
 const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
 const range=(a:number,b:number)=>a+(b-a)*random();
 const green=['#284444','#3a5147','#53614a','#66705b'].map(paint),stone=['#40576b','#6a786e','#7b7864'].map(paint),hay=paint('#8b8052'),wood=paint('#4e5141');
 const up=new T.Vector3(0,1,0),point=new T.Vector3(),normal=new T.Vector3(),tangent=new T.Vector3();
 function add(geo:T.BufferGeometry,mat:T.Material,x:number,y:number,z:number,sx=1,sy=1,sz=1){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=m.receiveShadow=true;scene.add(m);return m;}
 const groveCenters=[[-39,24],[39,23],[-63,-24],[70,-37],[-92,49],[83,79],[-35,92],[47,108],[-112,100],[112,110],[-92,-78],[100,-78],[-58,8],[-63,24],[66,10],[85,34],[-92,24],[58,78],[-24,145],[35,146]];
 for(const[cx,cz]of groveCenters){
  for(let j=0;j<9;j++){
   const x=cx+range(-9,9),z=cz+range(-9,9),y=ground(x,z),height=range(.6,2),r=range(.7,1.8);
   if(Math.hypot(x/35,(z-47)/22)<1)continue;
   const shrub=add(new T.SphereGeometry(1,10,8),green[Math.floor(random()*green.length)],x,y+height*.52,z,r,height*.6,r*.8);shrub.rotation.y=range(0,6.28);
   for(let i=0;i<150;i++){
    const a=range(0,Math.PI*2),yy=range(-.8,1),rr=Math.sqrt(1-yy*yy);
    normal.set(Math.cos(a),yy*.5,Math.sin(a)).normalize();point.set(x+Math.cos(a)*r*rr,y+height*.52+yy*height*.6,z+Math.sin(a)*r*.8*rr).addScaledVector(normal,.03);
    tangent.set(-Math.sin(a),.25,Math.cos(a)).normalize();brush.stroke(point,tangent,normal,range(.12,.4),range(.035,.08),['#3c5c51','#788166','#415a5c','#a39462'][Math.floor(random()*4)]);
   }
  }
  for(let j=0;j<6;j++){
   const x=cx+range(-12,12),z=cz+range(-12,12),r=range(.3,1.2),rock=add(new T.DodecahedronGeometry(1,0),stone[Math.floor(random()*3)],x,ground(x,z)+r*.25,z,r,r*.65,r*.8);rock.rotation.set(range(-.2,.2),range(0,6.28),range(-.3,.3));
  }
 }
 for(const[x,z]of[[-31,50],[-52,57],[32,62],[60,58],[-16,112],[25,126],[-110,-8],[112,32]]){
  if(Math.hypot(x/35,(z-47)/22)<1)continue;
  const y=ground(x,z),r=range(1.2,1.9),height=range(1.6,2.5);
  add(new T.SphereGeometry(1,16,12,0,Math.PI*2,0,Math.PI/2),hay,x,y,z,r,height,r*.85);
  for(let i=0;i<700;i++){
   const az=range(0,Math.PI*2),el=range(0,Math.PI/2),ce=Math.cos(el),se=Math.sin(el);
   normal.set(Math.cos(az)*ce,se,Math.sin(az)*ce).normalize();point.set(x+Math.cos(az)*ce*r,y+se*height,z+Math.sin(az)*ce*r*.85).addScaledVector(normal,.025);
   tangent.set(-Math.cos(az)*se,ce,-Math.sin(az)*se).normalize();brush.stroke(point,tangent,normal,range(.22,.65),range(.035,.09),['#8a8056','#ae9e67','#6f7358','#c0ad72'][Math.floor(random()*4)]);
  }
 }
 // Low wooden fences and stepping paths break up the open field edges.
 for(const[x,z,dx,dz]of[[-32,31,-1,.3],[33,32,1,.35],[-65,90,-.4,1],[66,99,.6,1]]){
  for(let i=0;i<10;i++){
   const xx=x+dx*i*1.7,zz=z+dz*i*1.7,yy=ground(xx,zz);
   add(new T.BoxGeometry(.11,1.15,.11),wood,xx,yy+.575,zz);
   if(i<9)for(const h of[.45,.9]){const rail=add(new T.BoxGeometry(1.8,.07,.07),wood,xx+dx*.85,yy+h,zz+dz*.85);rail.rotation.y=-Math.atan2(dz,dx);}
  }
 }
 const routes=[[[3,45],[-22,33],[-48,49],[-70,70],[-83,74]],[[6,50],[30,67],[46,90],[21,112],[-43,109]],[[26,-13],[48,-22],[71,-14],[91,-14]]];
 for(const route of routes){
  const curve=new T.CatmullRomCurve3(route.map(([x,z])=>new T.Vector3(x,0,z)));
  for(let i=0;i<2400;i++){
   const u=random();curve.getPoint(u,point);curve.getTangent(u,tangent);point.x+=range(-.7,.7);point.z+=range(-.7,.7);point.y=ground(point.x,point.z)+.06;
   brush.stroke(point,tangent,up,range(.2,.6),range(.035,.11),['#6d735e','#8b8768','#455b55'][Math.floor(random()*3)]);
  }
 }
 // Small bridge and bench beside the pond, with readable warm/cool faces.
 const bridgeY=ground(-83,74)+.9;
 for(let i=0;i<19;i++)add(new T.BoxGeometry(.78,.14,2.1),wood,-90.2+i*.8,bridgeY,74);
 for(const z of[72.95,75.05]){add(new T.BoxGeometry(16,.08,.08),wood,-83,bridgeY+.9,z);for(const x of[-90,-86,-82,-78,-76])add(new T.BoxGeometry(.12,1.35,.12),wood,x,bridgeY+.35,z);}
 for(const[x,z]of[[-65,68],[37,83]]){
  const y=ground(x,z);add(new T.BoxGeometry(2.2,.14,.6),wood,x,y+.65,z);add(new T.BoxGeometry(2.2,.52,.1),wood,x,y+1,z-.3);
  for(const dx of[-.8,.8])for(const dz of[-.2,.2])add(new T.BoxGeometry(.1,.65,.1),wood,x+dx,y+.325,z+dz);
 }
 const lampCore=new T.MeshBasicMaterial({color:'#dec780'});
 for(const[x,z]of[[-32,35],[50,25]]){
  const y=ground(x,z);add(new T.BoxGeometry(.13,2.1,.13),wood,x,y+1.05,z);add(new T.BoxGeometry(.28,.4,.28),lampCore,x,y+2,z);
  const lamp=new T.PointLight('#c9af6c',8,9,2);lamp.position.set(x,y+2.2,z);scene.add(lamp);
 }
 // Meadow landmarks: broad orchard crowns, dry stone borders and a farm cart.
 for(const[x,z]of[[-55,12],[-71,23],[61,8],[77,29],[-81,52],[65,82]]){
  const y=ground(x,z);add(new T.CylinderGeometry(.11,.22,2.6,8),wood,x,y+1.3,z);
  for(let j=0;j<7;j++){
   const a=j*Math.PI*2/7,r=j?1.25:0;
   add(new T.SphereGeometry(1,10,8),green[j%4],x+Math.cos(a)*r,y+2.6+range(-.25,.5),z+Math.sin(a)*r,1.4,1,1.35);
  }
 }
 for(const[cx,cz]of[[-62,15],[64,23],[-86,36],[78,81]])for(let i=0;i<15;i++){
  const x=cx+i*.62,z=cz+Math.sin(i*.25)*.5,y=ground(x,z);
  add(new T.DodecahedronGeometry(.42,0),stone[i%3],x,y+.32,z,.9,.9,1.15);
  if(i%2===0)add(new T.DodecahedronGeometry(.32,0),stone[(i+1)%3],x,y+.75,z,.95,.8,1);
 }
 const cartX=59,cartZ=18,cartY=ground(cartX,cartZ);
 add(new T.BoxGeometry(1.8,.18,1.15),wood,cartX,cartY+.7,cartZ);
 for(const dx of[-.86,.86])add(new T.BoxGeometry(.1,.65,1.2),wood,cartX+dx,cartY+1,cartZ);
 for(const dz of[-.7,.7]){
  const wheel=add(new T.TorusGeometry(.46,.075,6,16),wood,cartX,cartY+.46,cartZ+dz);wheel.rotation.y=0;
  for(let j=0;j<4;j++){const spoke=add(new T.BoxGeometry(.8,.045,.04),wood,cartX,cartY+.46,cartZ+dz);spoke.rotation.z=j*Math.PI/4;}
 }
 for(const dx of[-.4,.4])add(new T.BoxGeometry(.08,.08,2.1),wood,cartX+dx,cartY+.6,cartZ+1.5);
 // Fine undergrowth fills the meadow between the wheat patches without covering paths.
 const grassGeo=new T.BufferGeometry(),grassPositions:number[]=[];
 for(let j=0;j<5;j++){
  const a=j*Math.PI*2/5,x=Math.cos(a)*.16,z=Math.sin(a)*.16,h=.25+j*.065;
  grassPositions.push(x-.025,0,z,x+.025,0,z,x+Math.cos(a)*.12,h,z+Math.sin(a)*.12);
  grassPositions.push(x,0,z-.025,x,0,z+.025,x+Math.cos(a)*.12,h,z+Math.sin(a)*.12);
 }
 grassGeo.setAttribute('position',new T.Float32BufferAttribute(grassPositions,3));grassGeo.computeVertexNormals();
 const grassMat=paint('#adc0a4');grassMat.side=T.DoubleSide;
 const grassCount=innerWidth<700?9500:24000,grass=new T.InstancedMesh(grassGeo,grassMat,grassCount);grass.userData.dynamic=true;grass.receiveShadow=true;
 const grassTransform=new T.Object3D(),grassTint=new T.Color();
 for(let i=0;i<grassCount;i++){
  const[cx,cz]=groveCenters[i%groveCenters.length],a=range(0,Math.PI*2),r=Math.sqrt(random())*20,x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r;
  const dry=Math.hypot(x/35,(z-47)/22)>1&&!(Math.abs(x)<29&&z>-48&&z<23);
  grassTransform.position.set(x,ground(x,z),z);grassTransform.rotation.y=range(0,6.28);grassTransform.scale.setScalar(dry?range(.65,1.6):0);grassTransform.updateMatrix();grass.setMatrixAt(i,grassTransform.matrix);
  grassTint.set(['#64745a','#81906a','#425c53','#999366'][i%4]);grass.setColorAt(i,grassTint);
 }
 scene.add(grass);
 // Instanced flower clusters add detail without thousands of draw calls.
 const petals=new T.BufferGeometry(),positions:number[]=[],colours:number[]=[];
 function tri(a:number[],b:number[],c:number[],colour:T.Color){positions.push(...a,...b,...c);for(let i=0;i<3;i++)colours.push(colour.r,colour.g,colour.b);}
 const stalk=new T.Color('#3f6557'),bloom=new T.Color('#c2c6a0');
 tri([-.012,0,0],[.012,0,0],[0,.47,0],stalk);tri([0,0,-.012],[0,0,.012],[0,.47,0],stalk);
 for(let i=0;i<5;i++){const a=i*Math.PI*2/5,b=a+.55;tri([0,.47,0],[Math.cos(a)*.13,.48,Math.sin(a)*.13],[Math.cos(b)*.14,.5,Math.sin(b)*.14],bloom);}
 petals.setAttribute('position',new T.Float32BufferAttribute(positions,3));petals.setAttribute('color',new T.Float32BufferAttribute(colours,3));petals.computeVertexNormals();
 const flowerMaterial=paint('#a8b4b0');flowerMaterial.vertexColors=true;flowerMaterial.side=T.DoubleSide;
 const count=innerWidth<700?2600:6500,flowers=new T.InstancedMesh(petals,flowerMaterial,count);flowers.userData.dynamic=true;flowers.receiveShadow=true;
 const transform=new T.Object3D(),tint=new T.Color();
 for(let i=0;i<count;i++){
  const[cx,cz]=groveCenters[i%groveCenters.length],a=range(0,Math.PI*2),r=Math.sqrt(random())*15,x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r;
  transform.position.set(x,ground(x,z),z);transform.rotation.y=range(0,Math.PI*2);transform.scale.setScalar(range(.6,1.4));transform.updateMatrix();flowers.setMatrixAt(i,transform.matrix);
  tint.set(['#b5c6cb','#c2b974','#788ba6','#a7b59a'][i%4]);flowers.setColorAt(i,tint);
 }
 scene.add(flowers);
}

