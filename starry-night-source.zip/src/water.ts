import * as T from 'three';
import {Reflector} from 'three/addons/objects/Reflector.js';
import {CLOUD_LIGHT_GLSL} from './cloud-light';

/** Shared wave displacement and slope field: visible geometry, moving reflections. */
const waves=`
uniform float time;
vec3 waveField(vec2 p){
 float a=dot(p,vec2(.74,.31))*1.1-time*1.15;
 float b=dot(p,vec2(-.4,.91))*1.8-time*1.6;
 float c=dot(p,vec2(.92,-.38))*3.8-time*2.05;
 float h=.11*sin(a)+.055*sin(b)+.018*sin(c);
 vec2 slope=.11*vec2(.814,.341)*cos(a)+.055*vec2(-.72,1.638)*cos(b)+.018*vec2(3.496,-1.444)*cos(c);
 return vec3(slope,h);
}`;
const vertex=`
uniform mat4 textureMatrix; varying vec4 vReflection; varying vec3 vWorld; varying vec2 vBank;
${waves}
void main(){
 vec4 resting=modelMatrix*vec4(position,1.);
 vBank=(uv-.5)*2.;float shore=1.-smoothstep(.86,1.,length(vBank));
 vec3 p=position;p.z+=waveField(resting.xz).z*shore;
 vec4 world=modelMatrix*vec4(p,1.);vWorld=world.xyz;
 vReflection=textureMatrix*vec4(position,1.);
 gl_Position=projectionMatrix*viewMatrix*world;
}`;
const fragment=`
uniform sampler2D tDiffuse;uniform vec3 moonPosition;uniform float useReflection,waterLevel;
varying vec4 vReflection;varying vec3 vWorld;varying vec2 vBank;
${waves}
${CLOUD_LIGHT_GLSL}
void main(){
 float bank=length(vBank),shore=1.-smoothstep(.86,1.,bank);
 vec3 wave=waveField(vWorld.xz);
 vec3 fine=waveField(vWorld.xz*2.7+vec2(time*.12,-time*.1));
 vec3 n=normalize(vec3(-wave.x-fine.x*.15,1.,-wave.y-fine.y*.15));
 vec3 eye=normalize(cameraPosition-vWorld),light=normalize(moonPosition-vWorld);
 float fresnel=.07+.8*pow(1.-max(0.,dot(eye,n)),4.);
 vec2 reflectedUV=vReflection.xy/vReflection.w+n.xz*.045;
 vec3 actual=texture2D(tDiffuse,clamp(reflectedUV,.002,.998)).rgb;
 vec3 ray=reflect(-eye,n);
 float swirl=.5+.5*sin(ray.x*18.+ray.z*14.+sin(ray.y*12.+time*.15));
 vec3 sky=mix(vec3(.025,.055,.11),vec3(.11,.19,.28),swirl);
 vec3 reflection=mix(sky,actual*.78,useReflection);
 vec3 deep=vec3(.016,.047,.061),shallow=vec3(.075,.095,.067);
 vec3 color=mix(mix(shallow,deep,1.-smoothstep(.78,.96,bank)),reflection,fresnel);
 float moon=pow(max(0.,dot(n,normalize(eye+light))),120.);
 float cloud=cloudTransmission(vWorld,moonPosition,time);
 color+=vec3(.44,.34,.15)*moon*cloud;
 // Shore lamps are reflected by the same moving normal, breaking into short strokes.
 for(int i=0;i<9;i++){
  vec3 source=vec3((float(i)-4.)*4.1,2.,17.);
  vec3 l=normalize(source-vWorld);
  float glint=pow(max(0.,dot(n,normalize(eye+l))),240.);
  color+=vec3(.24,.13,.035)*glint*cloud;
 }
 float crest=smoothstep(.068,.105,wave.z)*(.35+.65*sin(vWorld.x*6.+time*.8)*sin(vWorld.x*6.+time*.8));
 color+=vec3(.025,.038,.044)*crest*shore;
 float shoreRipple=pow(.5+.5*sin((1.-bank)*190.-time*1.7+sin(vWorld.x*.8)),14.);
 color+=vec3(.008,.012,.009)*shoreRipple*smoothstep(.87,.98,bank);
 color*=.8+.2*cloud;
 gl_FragColor=vec4(color,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;

function surface(rx:number,rz:number){
 const g=new T.PlaneGeometry(rx*2,rz*2,innerWidth<700?64:112,innerWidth<700?48:88);
 const uv=g.getAttribute('uv'),old=g.index!,indices:number[]=[];
 for(let i=0;i<old.count;i+=3){
  const a=old.getX(i),b=old.getX(i+1),c=old.getX(i+2);
  const x=(uv.getX(a)+uv.getX(b)+uv.getX(c))/3*2-1,y=(uv.getY(a)+uv.getY(b)+uv.getY(c))/3*2-1;
  if(x*x+y*y<=1)indices.push(a,b,c);
 }
 g.setIndex(indices);g.computeBoundingSphere();return g;
}

export function buildWater(scene:T.Scene,ground:(x:number,z:number)=>number,time:{value:number},moonPosition:{value:T.Vector3}){
 const lake=new Reflector(surface(19,19),{textureWidth:innerWidth<700?256:512,textureHeight:innerWidth<700?256:512,multisample:0,clipBias:.005});
 lake.rotation.x=-Math.PI/2;lake.position.set(-15,-1.6,47);lake.userData.dynamic=true;
 const m=lake.material as T.ShaderMaterial;
 m.uniforms.time=time;m.uniforms.moonPosition=moonPosition;m.uniforms.useReflection={value:1};m.uniforms.waterLevel={value:-1.6};
 m.vertexShader=vertex;m.fragmentShader=fragment;
 // Render the real surroundings at 12 Hz; wave motion remains at display frame rate.
 const reflect=lake.onBeforeRender;let last=-Infinity;
 const reflectionLOD:{geometry:T.InstancedBufferGeometry;count:number}[]=[];
 lake.onBeforeRender=function(...args){
  if(time.value-last<1/12)return;last=time.value;
  if(!reflectionLOD.length)scene.traverse(object=>{
   const geometry=(object as T.Mesh).geometry;
   if(geometry instanceof T.InstancedBufferGeometry&&Number.isFinite(geometry.instanceCount))reflectionLOD.push({geometry,count:geometry.instanceCount});
  });
  // Subpixel brush marks do not need full density in a small reflection target.
  for(const item of reflectionLOD)item.geometry.instanceCount=Math.max(1,Math.floor(item.count*.25));
  try{reflect.apply(this,args);}finally{for(const item of reflectionLOD)item.geometry.instanceCount=item.count;}
 };
 scene.add(lake);
 const pondMaterial=new T.ShaderMaterial({uniforms:{time,moonPosition,useReflection:{value:0},waterLevel:{value:ground(-83,74)+.22},tDiffuse:{value:lake.getRenderTarget().texture},textureMatrix:{value:new T.Matrix4()}},vertexShader:vertex,fragmentShader:fragment});
 const pond=new T.Mesh(surface(12,7.8),pondMaterial);pond.rotation.x=-Math.PI/2;pond.position.set(-83,ground(-83,74)+.22,74);pond.userData.dynamic=true;scene.add(pond);
}
