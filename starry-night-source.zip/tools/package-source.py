"""Package only the editable project and local runtime assets for GitHub."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
with ZipFile(root / 'github-upload/starry-night-source.zip', 'w', ZIP_DEFLATED) as archive:
    for folder in ['src', 'dist', 'tools']:
        for file in sorted((root / folder).rglob('*')):
            if file.is_file() and '__pycache__' not in file.parts:
                archive.write(file, file.relative_to(root).as_posix())
    for name in ['package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'build.mjs', 'preview-server.mjs']:
        archive.write(root / name, name)
    archive.write(root / 'github-upload/README.md', 'README.md')
print('Packaged editable source and local assets.')
