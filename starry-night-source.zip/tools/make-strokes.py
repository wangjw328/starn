"""Extract deterministic brush positions, colour and local orientation from the public-domain painting."""
from pathlib import Path
from PIL import Image, ImageFilter
import numpy as np

root = Path(__file__).resolve().parents[1] / 'dist/assets'
im = Image.open(root / 'painting.jpg').convert('RGB').resize((1000, 792))
a = np.asarray(im).astype(np.float32) / 255
# Remove the painted cypress from the sky extraction: it is rebuilt as geometry.
# Interpolate the surrounding sky before calculating its direction field.
for row in range(45, 515):
    v = row / 792
    left = np.interp(v, [.055,.12,.30,.40,.64], [.193,.181,.178,.149,.108])
    right = np.interp(v, [.055,.12,.30,.40,.64], [.204,.213,.225,.252,.312])
    l, r = int(left*1000), int(right*1000)
    t = np.linspace(0, 1, r-l)[:,None]
    a[row,l:r] = a[row,l-5]*(1-t)+a[row,r+5]*t
lum = a @ np.array([.2126,.7152,.0722], dtype=np.float32)
gy, gx = np.gradient(lum)
def blur(a):
    return np.asarray(Image.fromarray(a, mode='F').filter(ImageFilter.GaussianBlur(2)))
# Pillow cannot blur float images on all builds: smooth with a separable box filter.
def smooth(a, radius=3):
    for axis in [0,1]:
        a = sum(np.roll(a,k,axis=axis) for k in range(-radius,radius+1))/(radius*2+1)
    return a
jxx,jxy,jyy = smooth(gx*gx), smooth(gx*gy), smooth(gy*gy)
angle = .5*np.arctan2(2*jxy,jxx-jyy)+np.pi/2
rng = np.random.default_rng(1889)
n = 105000
x,y = rng.random(n), rng.random(n)
ix,iy = (x*999).astype(int),(y*791).astype(int)
color = a[iy,ix]
# Color remains the painting's; conversion to linear matches Three.js output.
color = np.where(color<=.04045,color/12.92,((color+.055)/1.055)**2.4)
data = np.column_stack((x,y,angle[iy,ix],rng.random(n),color)).astype('<f4')
data.tofile(root/'strokes.bin')
print(f'Extracted {n:,} strokes, {data.nbytes:,} bytes')
