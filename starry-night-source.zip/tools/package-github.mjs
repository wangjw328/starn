import {build} from 'esbuild';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';

const out='github-upload';
await mkdir(out,{recursive:true});
const data='data:application/octet-stream;base64,'+(await readFile('dist/assets/strokes.bin')).toString('base64');
const result=await build({entryPoints:['./src/main.ts'],tsconfigRaw:{},bundle:true,minify:true,write:false,format:'iife',target:'es2022',legalComments:'inline',plugins:[{
 name:'embedded-paint',setup(build){
  build.onResolve({filter:/.*/},args=>{
   let file=args.path==='three'?path.resolve('node_modules/three/build/three.module.js'):args.path==='three/addons/utils/BufferGeometryUtils.js'?path.resolve('node_modules/three/examples/jsm/utils/BufferGeometryUtils.js'):path.resolve(args.resolveDir||process.cwd(),args.path);
   if(!path.extname(file))file+='.ts';return{path:file,namespace:'local-source'};
  });
  build.onLoad({filter:/.*/,namespace:'local-source'},async args=>({contents:(await readFile(args.path,'utf8')).replace("'./assets/strokes.bin'",JSON.stringify(data)),loader:args.path.endsWith('.ts')?'ts':'js',resolveDir:path.dirname(args.path)}));
 }
}]});
let html=await readFile('dist/index.html','utf8');
html=html.replace('<link rel="stylesheet" href="./style.css">','<style>'+(await readFile('dist/style.css','utf8'))+'</style>');
html=html.replace(/<script type="module" src="\.\/main\.js"><\/script>/,()=>'<script>'+result.outputFiles[0].text.replaceAll('</script','<\\/script')+'</script>');
if(html.includes('src="./main.js"'))throw Error('External main script was not replaced');
await writeFile(out+'/index.html',html);
await writeFile(out+'/THREE-LICENSE.txt',await readFile('dist/assets/THREE-LICENSE.txt'));
console.log('Self-contained GitHub Pages entry:',Buffer.byteLength(html),'bytes');
