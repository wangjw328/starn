import ts from 'typescript';
import {readFile,writeFile} from 'node:fs/promises';
for(const name of ['main','world','fields','sky','terrain-details','cloud-light','fireflies','water']){
 const source=await readFile(`src/${name}.ts`,'utf8');
 const result=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName:`${name}.ts`});
 const code=result.outputText.replaceAll("from 'three'","from './assets/three.module.js'").replaceAll("from 'three/addons/utils/BufferGeometryUtils.js'","from './assets/BufferGeometryUtils.js'").replaceAll("from './world'","from './world.js'").replaceAll("from './fields'","from './fields.js'").replaceAll("from './sky'","from './sky.js'").replaceAll("from './terrain-details'","from './terrain-details.js'").replaceAll("from './cloud-light'","from './cloud-light.js'").replaceAll("from './fireflies'","from './fireflies.js'").replaceAll("from './water'","from './water.js'").replaceAll("from 'three/addons/objects/Reflector.js'","from './assets/Reflector.js'");
 await writeFile(`dist/${name}.js`,code);
}
const utils=(await readFile('node_modules/three/examples/jsm/utils/BufferGeometryUtils.js','utf8')).replaceAll("from 'three'","from './three.module.js'");
await writeFile('dist/assets/BufferGeometryUtils.js',utils);
console.log('Built typed source and local Three.js modules → dist/');

await writeFile('dist/assets/Reflector.js',(await readFile('node_modules/three/examples/jsm/objects/Reflector.js','utf8')).replaceAll("from 'three'","from './three.module.js'"));
