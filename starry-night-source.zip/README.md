# 星月夜 · 自由空间

以梵高《星月夜》为灵感的 Three.js 三维探索空间。可以自由飞行、环顾、接近村庄与进入星云。

- 连续环绕的三维油彩笔触与分区卷云。
- 疏密错落的村庄、教堂、树丛与丘陵。
- 高低起伏的麦田、间歇传播的麦浪、独立飞行和闪烁的萤火虫。
- 月光、移动云影与暖色窗光。
- 桌面键鼠和手机触控操作。

## 本地运行

安装 Node.js，然后在项目目录执行：

```sh
npm install
npm run check
npm run build
npm run dev
```

访问 http://127.0.0.1:8797/ 。不要直接双击 HTML 文件。

WASD 飞行，Q/E 升降，Shift 加速，拖动鼠标环顾，滚轮前后穿行。数字 1—7 切换地点，R 返回起点，H 隐藏界面。

## GitHub Pages

仓库 Settings → Pages → Source 选择 GitHub Actions。推送到 main 会将已构建的 `dist/` 自动部署。修改源码后先运行 `npm run check` 与 `npm run build`，并将更新后的 `dist/` 一同提交。

所有运行依赖本地托管，页面路径为相对路径，支持 GitHub Pages 项目子目录。

## 源码

`src/main.ts` 负责操作与渲染循环；`world.ts` 构建场景；`sky.ts` 构建天空笔触；`fields.ts` 驱动麦田与麦浪；`fireflies.ts` 驱动萤火虫；`cloud-light.ts` 提供云影；`terrain-details.ts` 构建地面细节。

这是独立制作的艺术风格重建，并非原视频作者源码。天空与麦浪为程序化动画，不是物理流体模拟；建筑不含可进入室内。复杂场景的性能依赖设备。

## 素材与许可

Vincent van Gogh, The Starry Night, 1889。公有领域数字图像来自 [Wikimedia Commons / Google Art Project](https://commons.wikimedia.org/wiki/File:Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg)。`tools/make-strokes.py` 使用 Pillow 与 NumPy 生成笔触数据。

Three.js 0.180.0 为 MIT 许可，见 `dist/assets/THREE-LICENSE.txt`。
